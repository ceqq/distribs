========================================================================================================================
  Readme for
    exmp_win.pro
    exmp_nix.pro
========================================================================================================================

This summary project is supplied ONLY for quick testing buildability of all examples.

1. Ensure BMDX src_code folder placement at the same level as src_examples folder.

2. (Qt/qmake) To quickly build all examples on Windows, use exmp_win.pro.
  On any other system, use exmp_nix.pro.
  Note that certain compiler paths in the project files may require correction to match with your system.

3. (Qt/qmake) To quickly build particular example, use exmp_*_*.pro in the appropriate subfolder.

4. For building without Qt/qmake, all examples contain several bld_*/bld scripts
  for each supported system. The scripts call compilers directly,
  and should be modified first: specify the correct path to your compiler(s).
  (No automatic search done by the script.)

5. For running an example, first read readme.txt in the top-level folder of that example,
  to find out how many processes should be run, and with what options.
