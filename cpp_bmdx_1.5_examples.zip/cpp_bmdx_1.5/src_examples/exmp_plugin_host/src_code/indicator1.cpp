#include "common_elem_ampavg.h"
#include "../../../src_code/bmdx_main.h"
#include <iostream>

using namespace std;
using namespace bmdx;
using namespace bmdx_str::conv;

namespace ns_plhost
{

struct th_indicator : threadctl::ctx_base
{
  void _thread_proc()
  {
    // NOTE The indicator plugin instance (thread) is connected to 1 processor instance,
    //    and receives from it 1 data channel. The indicator is the final data consumer.


    // ========================================
    // During plugins initialization.
    // ========================================

      const unity& para = *pdata<unity>();
      unity __rphase = para["__host_phase"]; // this local object ensures that phase variable will exist at least until the current thread exits
      s_long& host_phase = __rphase.ref<s_long>();

      wstring inst_name = +para / "__inst_name" / L""; if (inst_name.empty()) { return; }
      const string title = +para / "title" / "*";

      const unity* pdep = para.path("depends"); if (!pdep) { return; }
      o_iptr_t<i_supplier> psup = pdep->hashi_c(1).pinterface<i_supplier>(); if (!psup) { return; }
      unity __q = psup->queue_create(inst_name, unity());
      t_queue_baa* qbavg = unity::o_api(&__q).pobj<t_queue_baa>(0x64); if (!qbavg) { return; }

      while (host_phase == 0)
      {
        // if (b_stop()) { return; } // not expected to be true because the thread is detached
        sleep_mcs(10000);
      }
      if (host_phase != 1) { return; }

    // ========================================
    // During normal work.
    // ========================================

      bool b_last = false;
      while (1)
      {
        // if (b_stop()) { return; } // not expected to be true because the thread is detached
        if (host_phase == 2) { return; }

        if (qbavg->navl() > 0)
        {
          const t_block_ampavg& a = qbavg->front();
          if (a.flags & 1) { b_last = true; }

          string s;
          for (s_long j = 0; j < a.samples.n(); ++j)
          {
            double amp = std::fabs(a.samples[j]);
            if (amp <= 1.e-6) { amp = 0; } else if (amp < 0.01) { amp = 0.01; } else if (amp > 1) { amp = 1; }
              string s_t = ftocs(a.t2_s(j), 6, 1); s_t += ' '; if (s_t.size() < 7) { s_t.resize(7, ' '); }
              string s_amp = ftocs(amp, 3); s_amp += ' '; if (s_amp.size() < 6) { s_amp.resize(6, ' '); }
              s += title + ' ' + s_t + s_amp + string(size_t(amp * 56), '=') + "\n";
          }
          cerr << s;

          qbavg->pop_1();
        }

        if (b_last) { break; }

        sleep_mcs(10000);
      }
  }
};

}

  // ========================================
  // Plugin instance creation.
  // ========================================
  //
  //  DESCRIPTION
  //
  //    The plugin instance creation code (bmdx_mod_request) is typical for all plugins in the example.
  //
  //    It is called two times per plugin instance with
  //      (*ppara)["__f"] ==
  //          1: instance initialization, step 1.
  //              Upward dependencies are not resolved yet.
  //              The current instance should return via *pretval
  //              an application-defined object, interface or other information,
  //              that helps dependent plugins to communicate with the current instance.
  //              The format of the above is application-defined.
  //          2: instance initialization, step 2.
  //              All upward dependencies are resolved, and initialized by step 1 above.
  //              The current instance may call any of the influencing instances as necessary,
  //              and should not return anything via *pretval.
  //
  //    NOTE The sequence of plugin instance creation calls at each of the two steps is how they are listed in plugin host configuration file,
  //      which is generally different from sequence of dependencies.
  //
  //  INPUT (*ppara)
  //
  //    ["__f"]: see "DESCRIPTION" above.
  //    ["__inst_name"'] == <NAME>. NAME: full instance name in the form <plugin name>.<instance name>
  //    ["__host_phase"].ref<s_long>() ==
  //        0: during initialization,
  //        1: during normal operation,
  //        2: during exit (all plugin instances must exit when see phase == 2).
  //        This flag is global (single variable for all plugins).
  //        Each plugin instance should store a copy of this variable until it exits,
  //        for plugin host to be able to determine by ref. counting when all instances have exited.
  //    ["__gfl_exit"].ref<s_long>():
  //        ref. to s_long gfl_exit variable.
  //        This flag is global (single variable for all plugins).
  //        Any plugin should set it to 1 if wants whole application to exit.
  //    ["depends"][<full instance name>]:
  //        upward dependencies of the plugin.
  //        On instance initialization, step 1, all dependencies are empty.
  //        On instance initialization, step 2, all dependencies are initialized by their appropriate plugins to application-defined object, interface or other information.
  //    ["__interface"]:
  //        exists only on ["__f"] == 2: the application-defined object, returned via *pretval on instance initialization step 1.
  //
  //  OUPUT (*pretval)
  //
  //    See "DESCRIPTION" above.
  //
  //  EXPECTED RET. CODE:
  //    1 - success.
  //    -1 - compatibility error.
  //    -2 - unrecognized action code.
  //    <= -10 - application-defined error code.
  //
using namespace ns_plhost;
extern "C" __BMDX_DLLEXPORT bmdx::s_long bmdx_mod_request(bmdx::s_long sig, bmdx::s_long action, const bmdx::unity* ppara, bmdx::unity* pretval)
{
  bmdx::unity::rqcheck __rc(sig, action, ppara, pretval); if (__rc <= 0) { return __rc; }
  try {
    const int f = +*ppara / "__f" / -1;
    if (f == 1)
    {
      pretval->clear(); // no interfaces created - the indicator is the final data consumer
      return 1;
    }
    else if (f == 2)
    {
      threadctl th;
      if (!th.start_auto<th_indicator>(*ppara)) { return -12; }
      th.detach();
      return 1;
    }
    return -10; // wrong __f param.
  } catch (...) {}
  return -12;
}
