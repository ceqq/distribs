#ifndef __common_elem_H
#define __common_elem_H

#include "../../../src_code/bmdx_main.h"

namespace ns_plhost
{
  using bmdx_meta::s_ll;
  using bmdx_meta::s_long;
  using namespace bmdx;

    // Queue element (in the scope of plugin host example project).
    //  NOTE The structure is designed as cross-module (compiler-independent).
    //    It consists of several 8-byte fields + 1 nested cross-module object.
  template<class T>
  struct _samples_block_t
  {
    s_ll ismp; // global index of the first sample in block
    double t_s; // absolute time (s) of the first sample, measured from start of sequence
    double smprate; // for this block only: number of samples per second
    s_ll flags; // 0x1: this block is the last in sequence, no more will be pushed (this is only for signaling about normal sequence end, not for error notifications)
    carray_r_t<T> samples;

    _samples_block_t() : ismp(0), t_s(0), smprate(0), flags(0) {}

    double t2_s() const { return t_s + (smprate ? samples.n() / smprate : 0); } // absolute time (s) of the after-end sample
    double dt_s() const { return (smprate ? samples.n() / smprate : 0); } // duration of the current samples
    double t2_s(s_ll i_rel) const { return t_s + (smprate ? i_rel / smprate : 0); } // absolute time (s) of the given sample index (relative to ismp)
    double dt_s(s_ll nsmp) const { return (smprate ? nsmp / smprate : 0); } // duration of the given number samples
  };

    // Simple queue allocation interface for all plugins, supplying data to other plugins.
  struct i_supplier
  {
      // Creates new queue object of application-defined type.
      //  name - unique queue name. Only 1 queue per name may be created.
      //  args - optional arguments, copied and kept together with the queue object.
      // Returns:
      //   a) on success (the queue has been created): the valid queue object of application-defined type.
      //    The object exists until the client releases the last reference to that object.
      //   b) on failure of if the queue already exists: empty.
    virtual unity queue_create(const unity& name, const unity& args = unity()) = 0;
    virtual ~i_supplier() {}
  };

}

  // Proxy class to support cross-module o_iptr_t for i_supplier.
namespace bmdx
{
  template<> struct o_proxy<ns_plhost::i_supplier> : o_proxy_base<ns_plhost::i_supplier>
  {
    static inline const char* __iname() { return "bmdx-dev/bmdx_example_plhost/i_supplier/2.0"; }

    struct __queue_create { typedef unity (*PF)(__Interface*, const unity*, const unity*); static unity F(__Interface* __pi, const unity* name, const unity* args) { return __pi->queue_create(*name, *args); } };
      virtual unity queue_create(const unity& name, const unity& args) { return __call<__queue_create>()(__psi(), &name, &args); }

    typedef unity_common::fn_list<__queue_create> __Methods;

  };
  namespace { o_proxy<ns_plhost::i_supplier> __o_proxy_ns_plhost_i_supplier_inst; }
}

#endif
