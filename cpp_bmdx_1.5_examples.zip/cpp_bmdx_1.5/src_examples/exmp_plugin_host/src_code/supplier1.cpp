#include "common_elem_samples.h"
#include "../../../src_code/bmdx_main.h"
#include "wav_reader_v1.h"

using namespace std;
using namespace bmdx;
using namespace bmdx_str::conv;
using namespace utils_audio;
using namespace utils_audio::wav_reader_v1;

struct __t_static_storage_selector {};
typedef svf_m_t<hashx<unity, unity>, __t_static_storage_selector> t_static_storage;

  // Implementation of struct i_supplier.
namespace bmdx
{
  struct t_queue_supplier_impl {};

  template<>
  struct o_iimpl<t_queue_supplier_impl, ns_plhost::i_supplier> : o_ibind<t_queue_supplier_impl, ns_plhost::i_supplier>, ns_plhost::i_supplier
  {
    virtual __t_i* __pMyI() { return this; }
    virtual void __itf_after_construct(s_long flags, o_itfset_base* src) { (void)flags; (void)src; }
    virtual void __itf_before_destroy(s_long flags) { (void)flags; }

      // name must be string (e.g. dependent plugin instance name).
      // args must specify an integer number of data channel.
    virtual unity queue_create(const unity& name, const unity& args)
    {
      try {
        if (!(name.isString() && args.isInt())) { return unity(); }
        t_static_storage::L __lock; if (!__lock.b_valid()) { return unity(); }
        t_static_storage s_hqueues;
        hashx<unity, unity>& h = s_hqueues.rxai0(); // rxai0 makes a static variable, with automatic initialization (0 args.)
        unity& rq = h[name];
          if (rq.isArray()) { return unity(); }
        unity q; q.objt<ns_plhost::t_queue_bs>(0)();
        rq.array(args, q);
        return rq;
      } catch (...) {}
      return unity();
    }
  };
}

namespace ns_plhost
{

struct th_supplier : threadctl::ctx_base
{
  void _thread_proc()
  {
    // NOTE The supplier plugin instance (thread) reads data from audio file (or generates samples, if source file is not specified),
    //    and supplies that data to multiple consumers. Each consumer receives only one chosen channel of data,
    //    though, multiple consumers may request the same channel.


    // ========================================
    // During plugins initialization.
    // ========================================

      const unity& para = *pdata<unity>();
      unity __rphase = para["__host_phase"]; // this local object ensures that phase variable will exist at least until the current thread exits
      s_long& host_phase = __rphase.ref<s_long>();

      // const unity* pdep = para.path("depends"); if (!pdep) { return; } // this plugin does not depend on any others

      double spr = bmdx_minmax::myffrange_lb(+para / "speed_ratio" / 1., 0.001, 10000); // dflt. 1x
      unity datasrc = +para / "datasrc" / unity();
        if (!(datasrc.isArray() || datasrc.isEmpty())) { datasrc = unity().array(datasrc); }

      while (host_phase == 0)
      {
        // if (b_stop()) { return; } // not expected to be true because the thread is detached
        sleep_mcs(10000);
      }
      if (host_phase != 1) { return; }

    // ========================================
    // During normal work.
    // ========================================

        // 1. Open .wav file.
        // 2. Loop:
        //    2.1 Prepare sample frames block container.
        //    2.2 Load N frames (according to sample rate, speed_ratio, and certain chosen latency), put into container.
        //    2.3 Set "the last block" flag if .wav file end reached.
        //    2.4 Push samples into all output queues.

      double smprate = 0; s_ll nfr_total = 0; wav_reader rd;
      if (datasrc.isEmpty()) { smprate = 44100; nfr_total = s_ll(60 * smprate); }
      else
      {
        for (s_long i = datasrc.arrlb(); i <= datasrc.arrub(); ++i) { string fn = datasrc.vcstr(i); if (file_utils().is_valid_path(fn)) { rd.fs_open(fn.c_str()); if (rd.fs_is_open()) { break; } } }
        if (!rd.fs_is_open())
        {
          return; // data file opening failed
        }
        smprate = rd.rate(); nfr_total = rd.nfr();
      }
      const s_ll nfr_part_dflt = bmdx_minmax::myllmax(1, s_ll(spr * smprate * 0.1)); // part size ~= 0.1 s
      s_ll ismp = 0; // abs. seq. sample number (it's assumed that sample rate never changes)




        // NOTE For example simplicity, any unexpected return from the main loop does not notify dependent plugins.
      const double tsend0 = clock_ms() / 1000;
      while (true)
      {
        // if (b_stop()) { return; } // not expected to be true because the thread is detached
        if (host_phase == 2) { return; }

          // true when the last iteration is reached.
        bool b_last = (host_phase != 1) || ismp + nfr_part_dflt >= nfr_total;


          // Get a working copy of the current set of queues (queues are held by reference).

        hashx<unity, unity> queues;
        try { t_static_storage::L __lock; if (__lock.b_valid()) { queues.hashx_copy(t_static_storage().rx(), 0); } } catch (...) {}



          // Prepare new blocks of samples (one block for each consumer's queue).

        hashx<s_ll, t_block_samples> hblocks; // { ind. of channel; data block of that channel }
        for (s_long i = 0; i < queues.n(); ++i)
        {
          t_block_samples& b = hblocks[queues(i)->v[1].vint()];
          b.ismp = ismp; b.t_s = 0 + ismp / smprate; b.smprate = smprate; if (b_last) { b.flags |= 1; }
        }


        // NOTE For example simplicity, possible failures (e.g. bad alloc.) in the below queue push/pop operations are ignored.
        //    In the real DSP code, they should have been processed such that client plugin instances
        //    did not lose synchronization on getting the next successful portion of data after such a failure.


          // Push samples into all new blocks.

        const s_ll nfr_part = bmdx_minmax::myllrange_lb(nfr_total - ismp, 0, nfr_part_dflt);

        if (datasrc.isEmpty()) // generated data
        {
          for (s_long j = 0; j < hblocks.n(); ++j)
          {
            t_block_samples& b = hblocks(j)->v;
            for (s_ll i = 0; i < nfr_part; ++i) { b.samples.append_1(float(std::sin(0.1 * (ismp + i) / smprate * 2 * 3.1415926))); }
          }
        }
        else // data from file
        {
          basic_string<sample32f> smpbuf;
          smpbuf.resize(nfr_part * rd.nch(), 0.F);
          if (rd.fs_read_32f(nfr_part, &smpbuf[0]) != nfr_part)
          {
            return; // data file end reached
          }
          for (s_long j = 0; j < hblocks.n(); ++j)
          {
            t_block_samples& b = hblocks(j)->v;
            const s_ll ichn = hblocks(j)->k;
            if (ichn >= 0 && ichn < rd.nch()) { for (s_ll i = 0; i < nfr_part; ++i) { b.samples.append_1(float(smpbuf[i * rd.nch() + ichn])); } }
              else { b.samples.append_nx(s_long(nfr_part), 0.F); }
          }
        }
        ismp += nfr_part;



          // Push blocks into consumer queues.

        if (nfr_part || b_last)
        {
          for (s_long i = 0; i < queues.n(); ++i)
          {
            t_queue_bs* q = queues(i)->v[2].objPtr<t_queue_bs>();
            if (q) { q->push_1(hblocks[queues(i)->v[1].vint()]); }
          }
        }


          // Check exit condition; calc. sleep time; do sleep.

        if (b_last)
        {
          return; // got the last block, exiting
        }
        if (1)
        {
          double tfact = clock_ms() / 1000 - tsend0;
          double tsync = double(ismp) / smprate / spr;
          s_ll tslp = s_ll((tsync - tfact) * 1e6);
          if (tslp < 100) { tslp = 100; }
          sleep_mcs(tslp);
        }
      }
  }
};

}

  // ========================================
  // Plugin instance creation.
  // ========================================
  //
  //  DESCRIPTION
  //
  //    The plugin instance creation code (bmdx_mod_request) is typical for all plugins in the example.
  //
  //    It is called two times per plugin instance with
  //      (*ppara)["__f"] ==
  //          1: instance initialization, step 1.
  //              Upward dependencies are not resolved yet.
  //              The current instance should return via *pretval
  //              an application-defined object, interface or other information,
  //              that helps dependent plugins to communicate with the current instance.
  //              The format of the above is application-defined.
  //          2: instance initialization, step 2.
  //              All upward dependencies are resolved, and initialized by step 1 above.
  //              The current instance may call any of the influencing instances as necessary,
  //              and should not return anything via *pretval.
  //
  //    NOTE The sequence of plugin instance creation calls at each of the two steps is how they are listed in plugin host configuration file,
  //      which is generally different from sequence of dependencies.
  //
  //  INPUT (*ppara)
  //
  //    ["__f"]: see "DESCRIPTION" above.
  //    ["__inst_name"'] == <NAME>. NAME: full instance name in the form <plugin name>.<instance name>
  //    ["__host_phase"].ref<s_long>() ==
  //        0: during initialization,
  //        1: during normal operation,
  //        2: during exit (all plugin instances must exit when see phase == 2).
  //        This flag is global (single variable for all plugins).
  //        Each plugin instance should store a copy of this variable until it exits,
  //        for plugin host to be able to determine by ref. counting when all instances have exited.
  //    ["__gfl_exit"].ref<s_long>():
  //        ref. to s_long gfl_exit variable.
  //        Any plugin should set it to 1 if wants whole application to exit.
  //        This flag is global (single variable for all plugins).
  //    ["depends"][<full instance name>]:
  //        upward dependencies of the plugin.
  //        On instance initialization, step 1, all dependencies are empty.
  //        On instance initialization, step 2, all dependencies are initialized by their appropriate plugins to application-defined object, interface or other information.
  //    ["__interface"]:
  //        exists only on ["__f"] == 2: the application-defined object, returned via *pretval on instance initialization step 1.
  //
  //  OUPUT (*pretval)
  //
  //    See "DESCRIPTION" above.
  //
  //  EXPECTED RET. CODE:
  //    1 - success.
  //    -1 - compatibility error.
  //    -2 - unrecognized action code.
  //    <= -10 - application-defined error code.
  //
using namespace ns_plhost;
extern "C" __BMDX_DLLEXPORT bmdx::s_long bmdx_mod_request(bmdx::s_long sig, bmdx::s_long action, const bmdx::unity* ppara, bmdx::unity* pretval)
{
  bmdx::unity::rqcheck __rc(sig, action, ppara, pretval); if (__rc <= 0) { return __rc; }
  try {
    const int f = +*ppara / "__f" / -1;
    if (f == 1)
    {
      pretval->clear();
      pretval->objt<t_queue_supplier_impl>(0)();
      if (pretval->objItfsAttach<o_interfaces<t_queue_supplier_impl, ns_plhost::i_supplier> >() < 0) { return -12; }
      return 1;
    }
    else if (f == 2)
    {
      threadctl th;
      if (!th.start_auto<th_supplier>(*ppara)) { return -12; }
      th.detach();
      return 1;
    }
    return -10; // wrong __f param.
  } catch (...) {}
  return -12;
}
