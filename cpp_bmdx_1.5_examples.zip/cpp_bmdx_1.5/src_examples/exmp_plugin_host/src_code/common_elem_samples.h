#ifndef __common_elem_samples_H
#define __common_elem_samples_H

#include "common_elem.h"

namespace ns_plhost
{
  typedef _samples_block_t<float> t_block_samples;
  typedef vnnqueue_t<t_block_samples> t_queue_bs;
}
namespace yk_c
{
  template<> struct bytes::type_index_t<ns_plhost::t_queue_bs> : cmti_base_t<ns_plhost::t_queue_bs, 2020, 3, 9, 12, -1> {};
  namespace { bytes::type_index_t<ns_plhost::t_queue_bs> __cmti_inst_ns_plhost__t_queue_bs; }
}

#endif
