========================================================================================================================
  Readme for
    exmp_plugin_host
========================================================================================================================

  About the project.

    This project presents a generic host application,
      which is able to load and execute multiple plugins.

    For testing the host, three cooperating plugins are included,
      each as separate project that may be built (as shared library)
      with individual choice of compiler and build options.

    The host does not know specifics of the hosted plugins,
      it requires only the pre-defined procedure in the plugin for plugin instance creation,
      and supplies two global variables (work stage and request for exit).

    By example design, the host and the plugins do NOT use any special communication means
      (shared memory, message queues etc.), while this is not a limitation for new plugins of any kind.

========================================================================================================================

  About the example plugins.

    Logically, 3 plugins form a chain:
      pl_supplier --> pl_processor --> pl_indicator

    pl_supplier: loads audio data file (.wav), and pushes its samples (grouped into blocks)
      into queue(s), created according to configuration of pl_processor instance(s).
      The supplier may be configured to push samples either with real-time rate,
      or with multiple of that.

    pl_processor: averages the supplied audio samples, based on the configured time window duration,
      and pushes the resulting amplitude values into queue(s),
      created according to configuration of pl_indicator instance(s).

    pl_indicator: receives amplitude values, and displays them as numbers and characters on the console,
      i.e. works as "volume indicator".

========================================================================================================================

  Build notes.

    1. Ensure BMDX library downloaded and unpacked so that src_code folder was placed
      aside (at the same level with) src_examples folder.
    2. Choose one of bld_* folders with build scripts, most closely matching with your target system.
    3. Correct bld_*/bld script so that compiler paths in the script were correct for your system.
    4. Note. Almost all scripts contain instructions for two compilers, one of which is likely
      the main system compiler.
      If both compilers are installed, any of them may be chosen to separately build host executable
      and each plugin, via bld script arguments.
      E.g. "./bld 1 2 2 2" will use compiler 1 to build main executable,
      and compiler 2 for all three example plugins.
    5. Run the chosen script in its own directory (e.g. ./bld).
      If all goes well, it creates 4 binaries + source data + config. file
      in that directory and reports BUILD SUCCEEDED.

    (6). Alternatively, the projects may be built with Qt/qmake.
      Use exmp_plhost_win.pro or exmp_plhost_nix.pro depending on the type of your system.
      Note that certain compiler paths in the project files may require correction to match with your system.
      The resulting binaries and data files are placed into out_bin folder at one level with src_examples folder.

========================================================================================================================

  Running the example.

    Depending on the target system: run ./plhost or plhost.exe.

========================================================================================================================

  Additional info.

    1. See comments near bmdx_mod_request in the example plugins.
    2. See host configuration file (plhost.cfg).
