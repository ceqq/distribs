#include "../../src_code/bmdx_main.h"
#include <iostream>

using namespace std;
using namespace bmdx;

struct __test_op_timeout_handler
{
  double dto_ms, t0;
  __test_op_timeout_handler(double dto_ms_) { dto_ms = dto_ms_; reset(); }
  operator bool() const { if (clock_ms() - t0 >= dto_ms) { return true; } sleep_mcs(100); return false; }
  void reset() { t0 = clock_ms(); }
};

struct test_thread_a : threadctl::ctx_base
{
  typedef arrayref_t<char> t_stringref;
  void _thread_proc() { this->exec(*pdata<unity>()); }
  void exec(unity& args)
  {
    s_long res; unity mr;
    __test_op_timeout_handler to(7000);

    std::ostream& log = +args[1]; (void)&log;
    s_long& res_th = +args[2]; res_th = -2;
    o_iptr_t<i_dispatcher_mt> a = args[3].pinterface<i_dispatcher_mt>();

    const vec2_t<cref_t<t_stringref> >& data = +args[4];
    unity ms = args[5];
      ms("src", "po_1");
      // ms["trg"][4] = "qi_1"; // target address already given by exec()
      ms("text").clear();
    const s_long flags_msend = args[6].vint_l();
    const s_ll nbmsg = args[8].vint();
    double& dtms = +args[9]; dtms = 0;
    const s_ll nruns = +args / 11 / 1ll;

    for (s_ll irun = 0; irun < nruns; ++irun)
    {
        // Waiting for thread B getting ready.
      to.reset(); do { res = a->mget("qi_feedback", mr); } while (res == 0 && !to && !b_stop()); if (res != 1) { res_th = -__LINE__; return; }
      if (mr["text"] != "ready") { res_th = -__LINE__; return; }

        // Sending the data to trg, specified by parent thread.
      for (s_long i = 0; i < data.n(); ++i)
      {
        if (b_stop()) { res_th = -__LINE__; return; }
        res = a->msend(ms, data[i], flags_msend); if (res != 1) { res_th = -__LINE__; return; }
      }

        // Waiting for feedback from thread B. NOTE May take long on virtual machine.
      to.dto_ms = 20000;
      to.reset(); do { res = a->mget("qi_feedback", mr); } while (res == 0 && !to && !b_stop()); if (res != 1) { res_th = -__LINE__; return; }
      to.dto_ms = 70000;
      unity& ret = mr["text"];
      if (!(ret.isArray() && ret[1] == "test succeeded")) { res_th = -__LINE__; return; }

        // Calc. statistics.
      const double dt = ret[2].vfp();
      if (nruns > 1) { log << _fls75("A irun ") + irun + "; perf., MB/s " + s_ll(nbmsg) * (data.n() - 1) / (dt / 1000) / (1024 * 1024) + "\n"; }
      dtms += dt;
    }

    res_th = 1;
  }
};
struct test_thread_b : threadctl::ctx_base
{
  typedef arrayref_t<char> t_stringref;
  void _thread_proc() { this->exec(*pdata<unity>()); }
  void exec(unity& args)
  {
    __test_op_timeout_handler to(7000);
    s_long res; unity mr;

    std::ostream& log = +args[1]; (void)&log;
    s_long& res_th = +args[2]; res_th = -2;
    o_iptr_t<i_dispatcher_mt> b = args[3].pinterface<i_dispatcher_mt>();

    const s_long nmsgs = args[4].vint_l();
    unity ms = args[5];
      ms("src", "po_feedback");
      // ms["trg"][4] = "qi_feedback"; // target address already given by exec()
      const unity ms_trg_prc = ms["trg"][2];
    const s_long flags_mget = args[6].vint_l();
    const s_ll nunique = args[7].vint();
    const s_ll nbmsg = args[8].vint();
    const s_ll flags_th = +args / 10 / 0ll;
    const s_ll nruns = +args / 11 / 1ll;
    const bool b_prealloc = !!(flags_th & 2);

    vec2_t<cref_t<t_stringref> > data;

    if (b_prealloc)
    {
      data.reserve(nmsgs); data.vec2_setf_can_shrink(false);

      const s_ll nmsgs_hint = nmsgs + (nruns > 1 ? 1 : 0); // 1 is added for case of allocations wrapping around the area
      const s_ll nbwmsg_max = 2000; // > max. size of main dispatcher message (wstring) in encoded form
      cref_t<bmdx_shm::i_allocctl> al = bmdx_shm::allocctl_pre::create(0xff, (nbmsg + nbwmsg_max) * nmsgs_hint, nmsgs_hint); if (!al) { res_th = -__LINE__; return; }
      unity args, retval;
        args("peer_name", ms_trg_prc);
        args("conf_set_al_in")("p_al", unity(al, false))("timeout_ms", 500);
        args("conf_set_lqcap")("b_receiver", true)("ncapmin", -1)("ncapmax", -2)("nrsv", nmsgs)("timeout_ms", 500);
      s_long res = b->request(dispatcher_mt_rt::set_shmqueue_conf, retval, args); if (res != 1) { res_th = -__LINE__; return; }
    }

    for (s_ll irun = 0; irun < nruns; ++irun)
    {
      ms("text", "ready");
        // NOTE msend() call is placed into a loop only for case when the user manually runs "bulk b" before "bulk a".
        //  In all other cases thread (process) B starts when thread (process) A already exists, so single msend() is enough.
      to.reset(); do { res = b->msend(ms); } while (res != 1 && !to && !b_stop()); if (res != 1) { res_th = -__LINE__; return; }

      double t0 = 0;

        for (s_long i = 0; i < nmsgs; ++i)
        {
          if (b_stop()) { res_th = -__LINE__; return; }
          cref_t<t_stringref> att;
          to.reset(); do { res = b->mget("qi_1", mr, &att, flags_mget); } while (res == 0 && !to && !b_stop()); if (res != 2) { res_th = -__LINE__; return; }
            if (!(att->n() == nbmsg && ((int)att->opsub(nbmsg - 1) & 0xff) == ((1 + i % nunique) & 0xff))) { res_th = -__LINE__; return; } // check one byte of data for correctness
            data.push_back(att);
          if (i == 0) { t0 = clock_ms(); } // starting point of measurements is inside transfer process (expected to be more precise)
        }

      const double dt_transfer = clock_ms() - t0;

        // NOTE In the current version, thread B does not have to track for the last feedback message being received by thread A.
        //  On exit, dispatcher_mt automatically waits for sending all pending messages
        //  at least during __bmdx_disp_lq_cleanup_dtms (1.5 s).
      ms("text").array("test succeeded", dt_transfer);
      res = b->msend(ms); if (res != 1) { res_th = -__LINE__; return; }

      data.el_remove_all();
      if (nruns > 1) { log << _fls75("B irun ") + irun + ": succeeded\n"; }

    }

    res_th = 1;
  }
};

struct test
{
  typedef arrayref_t<char> t_stringref;

    // Common part.
  bool run_a, run_b, run_prc2, b_peer2, b_prealloc;
  s_ll Nunique, Nbmsg, Nmsgs, Nruns;
  wstring __pn_root, pname1, pname2;

    // Data supplier part.
  vec2_t<cref_t<t_stringref> > data;
  wstring cfga;
  cref_t<dispatcher_mt> da;
    unity prxa, argsa; // NOTE must be declared after da, to avoid deadlock on exit
  s_long res_a, fla; double dtms;

    // Data consumer part.
  wstring cfgb;
  cref_t<dispatcher_mt> db;
    unity prxb, argsb; // NOTE must be declared after db, to avoid deadlock on exit
  s_long res_b, flb;

  test()
  {
      // Common part.
    run_a = run_b = 1; run_prc2 = 0; b_peer2 = 0; b_prealloc = 0;

    Nunique = 50; Nbmsg = 20 * 1024 * 1024; Nmsgs = Nunique; // if Nunique < Nmsgs: repeated sending data[0..Nunique-1] until Nmsgs messages are sent
    Nruns = 1;

    __pn_root = L"test_bmdx_unity_";
    pname1 = __pn_root + L"supplier";
    pname2 = __pn_root + L"consumer";

    s_long fl_anlo = 0;
      // fl_anlo |= dispatcher_mt_flags::use_chsbin; // this flag decreases transfer speed (up to 8x from max. possible)
      fl_anlo |= dispatcher_mt_flags::anlo_att; // this flag (must be set in both peers) minimizes binary data copying and thus increases transfer speed to max. possible

      // Data supplier part.
    cfga = L"=|thread1|slots; po_1; qi_1; qi_feedback";
    fla = fl_anlo;
    res_a = 0;
    dtms = 0;

      // Data consumer part.
    cfgb = L"=|thread1|slots; po_feedback; qi_1";
    flb = dispatcher_mt_flags::get_hashlist | fl_anlo;
    res_b = 0;
  }

  int exec()
  {

    try {

      const s_long flags_th = (b_peer2 ? 1 : 0) | (b_prealloc ? 2 : 0);
      if (run_a)
      {
          // Supplier: generate some data.
        try {
          for (int i = 0; i < Nunique; ++i) { data.push_back(i_dispatcher_mt::make_rba_z(Nbmsg)); if (!data.back()) { return -__LINE__; } t_stringref d = data.back().ref(); for (int j = 0; j < Nbmsg; j += 511) { d[j] = char(j); } d[Nbmsg - 1] = i + 1; }
          for (s_ll i = Nunique; i < Nmsgs; ++i) { data.push_back(data[s_long(i % Nunique)]); }
        } catch (...) { return -__LINE__; }

          // Supplier: prep. worker thread.
        da.create2(0, pname1, cfga);
        da->new_proxy(prxa, "thread1");
          if (!prxa.isObject()) { return -__LINE__; }
        argsa.array(unity(cerr, false), unity(res_a, false), prxa, unity(data, false), paramline().decode(L"trg = |LM|" + pname2 + L"|thread1|qi_1", 0), fla, Nunique, Nbmsg, unity(dtms, false), flags_th, Nruns);
      }

      bool run_b_inpr = run_b && !run_prc2; // run consumer thread inside the current process
      if (run_b_inpr)
      {
          // Consumer: prep. worker thread.
        db.create2(0, pname2, cfgb);
        db->new_proxy(prxb, "thread1");
          if (!prxb.isObject()) { return -__LINE__; }
        argsb.array(unity(cerr, false), unity(res_b, false), prxb, Nmsgs, paramline().decode(L"trg = |LM|" + pname1 + L"|thread1|qi_feedback", 0), flb, Nunique, Nbmsg, unity(), flags_th, Nruns);
      }

      threadctl tb;
      if (run_b_inpr && !tb.start_auto<test_thread_b>(argsb)) { return -__LINE__; }

      processctl pb;
      if (run_prc2)
      {
        _fls75 args = "b2";
        if (b_prealloc) { args += 'p'; }
        args += '\0'; args += Nruns;
        if (!pb.launch(unity(cmd_myexe()).vcstr(), args.str())) { return -__LINE__; }
      }

      threadctl ta;
      if (run_a && !ta.start_auto<test_thread_a>(argsa)) { return -__LINE__; }

      console_io cons(!b_peer2);
      while ((run_a && ta) || (run_b_inpr && tb) || (run_prc2 && pb.is_running()))
      {
        if (cons.ugetch() == 0x1b)
        {
          cerr << "ESC pressed. Exiting.\n";
          ta.signal_stop(); tb.signal_stop(); const double t0 = clock_ms(); while (1) { if (!(ta || tb)) { break; } if (clock_ms() - t0 > 1000) { cerr << "Long wait. Terminating threads.\n"; ta.terminate(); tb.terminate();  } sleep_mcs(10000); }
          return -__LINE__;
        }
        sleep_mcs(10000);
      }

      bool b_good = true;
      if (run_a && !(res_a == 1 && dtms > 0)) { b_good = false; cerr << "ERR res_a, dtms: " << res_a << " " << dtms << "\n"; }
      if (run_b_inpr && !(res_b == 1)) { b_good = false; cerr << "ERR res_b: " << res_b << "\n"; }
      if (!b_good) { return -__LINE__; }

      if (run_a) { cout << "dispatcher_mt po-->qi perf. avg., MB/s " << s_ll(Nbmsg) * (Nmsgs - 1) * Nruns / (dtms / 1000) / (1024 * 1024) << "\n"; }

      return 1;
    } catch (...) { return -__LINE__; }
  }

};

int main(int argc, char** argv)
{
  test t;
    if (argc < 2)
    {
      cout << "Bulk transfer test. Usage:\n"
        " bulk [p] -- tests supplier/consumer in the same process; opt. 'p' - receival into pre-allocated memory.\n"
        " bulk ab[p]  -- tests supplier/consumer in two processes (the second is run automatically).\n"
        " bulk [a or b][p]  -- runs the chosen side ('a' supplier, 'b' consumer).\n"
        " Also: for N>=2 test runs, specify N as 2nd argument.\n"
        ;

      t.run_a = t.run_b = 1; t.run_prc2 = t.b_peer2 = t.b_prealloc = 0;
    }
    else
    {
      bool a = !!strchr(argv[1], 'a'), b = !!strchr(argv[1], 'b'), p = !!strchr(argv[1], 'p'), _ = !!strchr(argv[1], '_'), two = !!strchr(argv[1], '2');
      t.run_a = a || _ || (!a && !b); t.run_b = b || _ || (!a && !b); t.run_prc2 = a && b; t.b_peer2 = b && two && !a; t.b_prealloc = p;
    }
    if (argc >= 3) { t.Nruns = bmdx_minmax::mylmax(1, atoi(argv[2])); }

  if (t.run_a || t.run_b) { cout << "Running...\n"; }

  int res = t.exec();
  if (res == 1) { return 0; }
  cerr << "ERR t.exec(): " << res << "\n";
  // cin.get();
  return -res;
}
