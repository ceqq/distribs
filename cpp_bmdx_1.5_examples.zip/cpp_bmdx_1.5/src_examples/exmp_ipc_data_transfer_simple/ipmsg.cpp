#include "../../src_code/bmdx_cpiomt.h"
using namespace bmdx_shm;

#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv)
{
    // Figure out if the program runs as server or client (i.e. what to do with i/o buffers).
  const bool b_server = (string(argv[0]).find("server") != string::npos) || (argc >= 2 && string(argv[1]) == "s");
  #define __b_multiclient 1 // 1: allow many clients to send messages to server; 0: allow only one client (others will fail until it exits)

  shmqueue_s req("BMDXMsgQueueDir21", -1, 1, 0);
  shmqueue_s resp("BMDXMsgQueueDir12", -1, 1, 0);

  bmdx::console_io cons;
  string s;

  if (b_server)
  {
    cout << "SERVER: waiting for message (ESC to exit)..." << endl;

    while (cons.ugetch() != 0x1b) // ESC
    {
      try { s = req.mget_str(100); } catch (...) { continue; } // automatically creates the input queue at the first call
      if (req.res < 0) { cout << "SERVER: mget_str: " << req.res << " (failure)" << endl; }

      if (req.res > 0)
      {
        cout << "SERVER: got message: [" << s << "]" << endl;
        cout << "SERVER: responding (echo)..." << endl;
        resp.msend(s); // non-blocking, should succeed because the client should already be alive
        if (resp.res != 0) { cout << "SERVER: msend: " << resp.res << (resp.res > 0 ? " (success)" : " (failure)") << endl; }
      }
    }
  }
  else
  {
    cout << "CLIENT: sending message..." << endl;

    req.bufstate(2); resp.bufstate(3); // create/connect to input queues, to allow server responding successfully at once
    req.msend(string() + "Hello! Message from client " + argv[0], -1);
    cout << "CLIENT: msend: " << req.res << (req.res > 0 ? " (success)" : " (failure)") << endl;
    if (req.res > 0)
    {
      s = resp.mget_str(-1);
      if (resp.res > 0) { cout << "CLIENT: got response: [" << s << "]" << endl; }
      if (resp.res <= 0) { cout << "CLIENT: mget_str: " << resp.res << " (failure)" << endl; }
    }

    cout << endl << endl << "TYPE MESSAGE YOURSELF. ESC to exit program." << endl;
    while (true)
    {
      s.clear();
      #if __b_multiclient
        req.bufstate(6); resp.bufstate(7); // disconnect from shared queues, until the user completes typing a message
      #endif
      bool b_esc = false;
      while (true)
      {
        char c = cons.ugetch();
        if (c == 0x1b) { b_esc = true; break; }
        if (c == 0) { bmdx::sleep_mcs(20000); continue; }

        if (c == 0xd || c == 0xa) { cout << endl; break; }
        s += c;
        cout << c;
      }
      if (b_esc) { break; }
      #if __b_multiclient
        while (1)
        {
          if (cons.ugetch() == 0x1b) { b_esc = true; break; }
          req.bufstate(4); resp.bufstate(5); // begin connecting to shared queues
          bmdx::sleep_mcs(500); // give some time to connect
          if (req.bufstate(0) == 3 && resp.bufstate(1) == 3) { break; }
          req.bufstate(6); resp.bufstate(7); bmdx::sleep_mcs(5000); // yield queues to another client for some time
        }
      #endif
      if (b_esc) { break; }

      double t0 = bmdx::clock_ms();
      req.msend(s, -1);
      cout << "CLIENT: msend: " << req.res << (req.res > 0 ? " (success)" : " (failure)") << endl;
      if (req.res > 0)
      {
        s = resp.mget_str(-1);
        double t1 = bmdx::clock_ms();
        if (resp.res > 0) { cout << "CLIENT: got response: [" << s << "]" << endl << "  roundtrip time, ms: " << (t1 - t0) << endl; }
        if (resp.res <= 0) { cout << "CLIENT: mget_str: " << resp.res << " (failure)" << endl; }
      }
    }

  }

  return 0;
}
