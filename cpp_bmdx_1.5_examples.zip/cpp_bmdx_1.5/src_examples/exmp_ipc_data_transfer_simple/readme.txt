========================================================================================================================
  Readme for
    exmp_ipc_data_transfer_simple
========================================================================================================================

  This project demonstrates passing binary strings between pair of programs,
    via shared memory.
    In the scope of the example, strings are taken from user input on the console.
    One of the programs acts as echo server.
    Another is the client. The client always displays the echoed message and the time
    taken to send the message to server and receive it back.

========================================================================================================================

  Build notes.

    1. Ensure BMDX library downloaded and unpacked so that src_code folder was placed
      aside (at the same level with) src_examples folder.
      Note that the example uses only bmdx_cpiomt.h as standalone header.
    2. Choose one of bld_* folders with build scripts, most closely matching with your target system.
    3. Correct bld_*/bld script so that compiler paths in the script were correct for your system.
    4. Note. Almost all scripts contain instructions for two compilers, one of which is likely
      the main system compiler.
      If both compilers are installed, any of them may be chosen to separately build
      client and server executable, via bld script arguments.
      E.g. "./bld 1 2" will use compiler 1 to build client, and compiler 2 for the server.
    5. Run the chosen script in its own directory (e.g. ./bld).
      If all goes well, it creates 2 binaries therein:
      a) ipmsg, ipmsg_server.
      b) ipmsg.exe, ipmsg_server.exe.

    (6). Alternatively, the project may be built with Qt/qmake.
      Use exmp_ipmsg_win.pro or exmp_ipmsg_nix.pro depending on the type of your system.
      Note that certain compiler paths in the project files may require correction to match with your system.
      The resulting executable (client only) is placed into out_bin folder at one level with src_examples folder.

========================================================================================================================

  Running the example.

    Depending on the target system:
      a) run ./ipmsg_server, then ./ipmsg.
      b) run ipmsg_server.exe, then ipmsg.exe.

    Note A. By default, the client (ipmsg) is built as "multiclient", i.e. several instances may be run,
      and each of them will communicate with the same server. See also ipmsg.cpp.

    Note B. By example design, the client and server executables are the same.
      If the program finds "server" in its own name,
      or receives "s" as first argument, it starts as server, otherwise as client.

    Note C. The server may be closed and re-run. Communication with existing clients is resumed automatically.
