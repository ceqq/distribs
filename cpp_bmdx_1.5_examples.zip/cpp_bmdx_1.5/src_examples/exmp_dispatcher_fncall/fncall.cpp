#include "../../src_code/bmdx_main.h"
#include <iostream>

using namespace std;
using namespace bmdx;

  // Convenience class for any strong-bound, function-like call via BMDX dispatcher.
struct fncall
{
  unity proxy; // wrapped i_dispatcher_mt
  o_iptr_t<i_dispatcher_mt> pdisp; // pointer to proxy's i_dispatcher_mt

  fncall(const unity& proxy_) : proxy(proxy_), pdisp(proxy.pinterface<i_dispatcher_mt>()), resc(0), timeout_msend_ms(1000), timeout_mget_ms(1000), check_period_mcs(200) {}
  fncall(const dispatcher_mt& disp_, const unity& thread_name_) : resc(0), timeout_msend_ms(1000), timeout_mget_ms(1000), check_period_mcs(200) { disp_.new_proxy(proxy, thread_name_.vstr()); pdisp = proxy.pinterface<i_dispatcher_mt>(); }

  bool is_valid() const { return proxy.isObject() && pdisp && !src_sl.empty() && !trg_addr.empty(); }

    // Sets source slot name and destination address into this->src_sl, this->trg_addr, with some partial validity checking.
    //  E.g. "pbo_fn", "|LP|thread1|qbi_fn".
    //    Here, "fn" is application specific name root, should be same in src_sl, trg_addr.
    //    Name root may refer to one or several functions, as necessary.
    //    In case of several functions, function name or ID may be passed as call argument.
    //  NOTE Command source slot names must start from pbo_ or hbo.
    //    Command target slot names must start from pbi_ or qbi_.
    //    See also i_dispatcher_mt :: msend.
    //  On success, returns true.
    //  Otherwise, src_sl, trg_addr are cleared.
  bool set_srctrg(const unity& src_sl__, const unity& trg_addr__)
  {
    try {
      src_sl.clear(); trg_addr.clear();
      const wstring src_sl_ = src_sl__.vstr(), trg_addr_ = trg_addr__.vstr();
      size_t i1 = src_sl_[0] == '|' ? 1 : 0;
      wstring s = src_sl_.substr(i1, 4); if (!(src_sl_.length() >= 5 && (s == L"pbo_" || s == L"hbo_"))) { return false; }
      i1 += 3;
      size_t i2 = src_sl_.find('|', i1); if (i2 == wstring::npos) { i2 = src_sl_.size(); }
      s = src_sl_.substr(i1, i2 - i1);
      wstring s2 = trg_addr_.substr(0, 4);
      if (!(s2 == L"|LP|" || s2 == L"|LM|")) { return false; }
      i2 = trg_addr_.find(s);
      if (i2 == wstring::npos || i2 < 8) { return false; }
      s2 = trg_addr_.substr(i2 - 3, 4); if (!(s2 == L"pbi_" || s2 == L"qbi_")) { return false; }
      src_sl = src_sl_; trg_addr = trg_addr_;
      return true;
    } catch (...) {}
    return false;
  }


  wstring src_sl, trg_addr;
  s_long resc; // dispatcher thread call result (see in fncall::operator())
  s_long timeout_msend_ms; // if negative: "no timeout, repeat msend until it succeeds, or *pq_stop != 0"
  s_long timeout_mget_ms; // if negative: "no timeout, repeat mget until got a message, or *pq_stop != 0"
  s_long check_period_mcs; // sleep period between msend and mget tries
  unity h;
  cref_t<arrayref_t<char> > att;

    // The value, returned by the called function.
  unity& retval() { return h.isHash() ? h[L"text"] : h; }

    // args:
    //    a) string, starting from "|", represents ready array of input arguments, e.g. for "|1|2.5|abc" 3 arguments will be passed to the target function.
    //    b) string, starting from anything else than "|", is passed to the target function literally, as single argument.
    //      NOTE (a, b) are distinguished by operator() only for convenience, in the scope of the example project.
    //    c) any single scalar value.
    //    d) unity().array(...): an pre-made array of positional arguments.
    //  args should contain application-specific data. Whether args include target function name or not - is implementation-dependent.
    // pq_stop (optional): points to the current thread stop condition (0 - run normally, != 0 - exit immediately).
    //    See also threadctl :: struct ctx_base b_stop().
    // Expected behavior of the command target:
    //    1. Execute the requested function if possible.
    //    2. Send backward message with optional return value under "text" key.
    // Returns:
    //  this->resc - fncall::operator() result:
    //    3, 2, 1 - the call succeeded:
    //      If 3 - this->retval() contains an integer.
    //      If 2 - this->retval() contains non-integer.
    //      If 1 - this->retval() is empty (i.e. the function returned nothing).
    //    -1 - msend failure or timeout (probably, command target does not exist).
    //    -2 - common-case failure (fncall::operator() itself).
    //    -3 - fncall::operator() exited because of *pq_stop != 0.
    //    -4 - mget failure or timeout.
    //  this->h - on successful call: decoded reply (hashlist), otherwise empty.
    //  this->att - the received binary attachment (if any), otherwise empty.
  inline s_long operator()(const unity& args, volatile const s_long* pq_stop = 0) throw()
  {
    resc = -2; h.recreate();
    if (!is_valid()) { return resc; }
    try {
      const unity k_e_retry = L"_e_retry";
      unity msg0;
        msg0
          (L"src", unity().pl_dec1v(src_sl))
          (L"trg", unity().pl_dec1v(trg_addr))
          (L"text", args.isString() && args.rstr()[0] == '|' ? unity().pl_dec1v(args.rstr()) : args)
        ;
      const unity& sln = msg0[L"src"];
      for (int itry = 0; itry < 3; ++itry)
      {
        if (1)
        {
          s_long res = -10000;
          double t0 = clock_ms();
          while (timeout_msend_ms < 0 || clock_ms() - t0 < double(timeout_msend_ms))
          {
            if (pq_stop && !!*pq_stop) { resc = -3; return resc; }
            res = pdisp->msend(msg0);
            if (res == -5) { unity tmp; pdisp->request(9, tmp, msg0); continue; }
            if (res > 0) { break; }
            sleep_mcs(check_period_mcs);
          }
          if (res <= 0) { resc = -1; return resc; }
        }

        if (1)
        {
          bool b_retry = false;
          double t0 = clock_ms();
          while (timeout_mget_ms < 0 || clock_ms() - t0 < double(timeout_mget_ms))
          {
            if (pq_stop && *pq_stop >= 2) { resc = -3; return resc; }
            s_long res = pdisp->mget(sln, h, &att, 1);
            if (res > 0)
            {
              if (h.hash_locate(k_e_retry)) { h.clear(); b_retry = true; break; }
              unity& x = this->retval();
              resc = x.isInt() ? 3 : (x.isEmpty() ? 1 : 2);
              return resc;
            }
            if (res == -20) { sleep_mcs(check_period_mcs); continue; }
            break;
          }
          if (b_retry) { resc = -2; h.clear(); continue; }
          resc = -4; h.clear();
          return resc;
        }
      }
    }
    catch (...) {}
    resc = -2; h.clear();
    return resc;
  }
};

struct thread_callee : threadctl::ctx_base
{
  void _thread_proc()
  {
    unity& proxy = *pdata<unity>();
    o_iptr_t<i_dispatcher_mt> pdisp = proxy.pinterface<i_dispatcher_mt>();
    if (!pdisp) { cerr << "ERR Callee proxy.pinterface failed.\n"; }
    while (!b_stop())
    {
      try {
        unity msg, ret;
        if (pdisp->mget("qbi_sum", msg) > 0)
        {
          const unity& args = msg["text"];
          ret.clear();
          try { for (int i = 1; i <= args.arrub(); ++i) {
            const unity& x = args[i];
            if (ret.isFloat() || x.isFloat()) { ret = ret.vfp() + x.vfp(); }
              else { ret = ret.vint() + x.vint(); } // keep integer result as long as all inputs are integer
          } } catch (...) {}
          pdisp->msend(unity()("src", "qbi_sum")("trg", msg["src"])("text", ret)); // for simplicity: no msend errors checking
        } // for simplicity: no mget errors checking
        if (pdisp->mget("qbi_product", msg) > 0)
        {
          const unity& args = msg["text"];
          ret.clear();
          try { for (int i = 1; i <= args.arrub(); ++i) {
            const unity& x = args[i];
            if (ret.isEmpty()) { ret = x.isFloat() ? x : x.vint(); }
              else if (ret.isFloat() || x.isFloat()) { ret = ret.vfp() * x.vfp(); }
              else { ret = ret.vint() * x.vint(); } // keep integer result as long as all inputs are integer (integer overflow is ignored)
          } } catch (...) {}
          pdisp->msend(unity()("src", "qbi_product")("trg", msg["src"])("text", ret)); // for simplicity: no msend errors checking
        } // for simplicity: no mget errors checking
      } catch (...) {}
      sleep_mcs(100);
    }
  }
};

int main(int argc, char** argv)
{
  (void)argc; (void)argv;

    //  In this example, function calls are made between threads of the same process (main thread and callee thread).
    //    The callee code (see: thread_callee, threadctl th_b) may be easily extracted and run in separate process, with its own dispatcher with cfg2.

  string cfg1 = "=|thread1|slots; pbo_sum; pbo_product";
  string cfg2 = "=|thread2|slots; qbi_sum; qbi_product";

  dispatcher_mt disp("fncall_test_ab", cfg1 + '\n' + cfg2);
    if (!disp.has_session()) { cerr << "ERR dispatcher_mt init. failed [1].\n"; return __LINE__; }


    // Callee startup code.
  unity proxy; disp.new_proxy(proxy, "thread2");
    if (!proxy.isObject()) { cerr << "ERR Callee proxy creation failed.\n"; return __LINE__; }
  threadctl th_b;
    if (!th_b.start_auto<thread_callee>(proxy)) { cerr << "ERR Callee thread startup failed.\n"; return __LINE__; }


    // Prep. caller function objects.
    //    NOTE The caller code may be extracted and run in separate thread as well as callee.
    //      To ensure timely exit of such thread in case when it's waiting for callee for too long,
    //      fncall operator() should be given the 2nd arg.: thread's &this->b_stop() flag variable.
    //      See also fncall operator().
  fncall sum(disp, "thread1");
    sum.set_srctrg("pbo_sum", "|LP|thread2|qbi_sum");
  fncall prod(disp, "thread1");
    prod.set_srctrg("pbo_product", "|LP|thread2|qbi_product");

  if (!(sum.is_valid() && prod.is_valid())) { cerr << "ERR dispatcher_mt init. failed [2]\n"; return __LINE__; }

  sum("|1|2|3");
    if (sum.resc < 1) { cerr << "ERR sum() failed. resc: " << sum.resc; return __LINE__; }
    cout << "1+2+3 = " << sum.retval().vcstr() << "\n";

  prod("|2.1|3.3|5|10");
    if (sum.resc < 1) { cerr << "ERR sum() failed. resc: " << sum.resc; return __LINE__; }
    cout << "2.1*3.3*5*10 = " << prod.retval().vcstr() << "\n";

  cout << "Calls done, exiting.\n";

  // NOTE th_b will be automatically asked to close on th_b destruction.

  return 0;
}
