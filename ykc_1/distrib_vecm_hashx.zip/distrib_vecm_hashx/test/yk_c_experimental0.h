/*

In this module:
  storage_t,
  iterator_t.

USAGE NOTE

The following headers must be pre-included
if they are not in the same directory as this file:

vecm_hashx.h

*/

#ifndef yk_c_experimental0_H
#define yk_c_experimental0_H

#ifndef yk_c_vecm_hashx_H
	#include "vecm_hashx.h"
#endif

#include <iterator>

namespace yk_c
{
  namespace experimental
  {
      // storage_t(-1) == storage only, no automatic initialization and destruction.
      //    The client may do it manually or with try_init(), try_deinit().
      //  storage_t(0) == storage with automatic T destruction on bool(inited) == true. Initialization is done, if necessary,
      //    by the client, either manually (+ setting inited true on success), or with try_init().
      //  storage_t(1) == storage with automatic T construction and destruction.
      //  In all modes, try_init(), try_deinit() work correctly.
    template<class T, class Aux = meta::nothing>
    struct storage_t
    {
      template<int n1 = sizeof(T)  / sizeof(meta::s_ll), int n2 = sizeof(T)  % sizeof(meta::s_ll)> struct place { meta::s_ll x1[n1]; char x2[n2]; };
      template<int n> struct place<n, 0> { meta::s_ll x1[n]; };
      template<int n> struct place<0, n> { char x2[n]; };
      mutable place<> pl;
      char inited;
      const signed char mode;
      inline storage_t(s_long mode_) throw() : inited(false), mode((signed char)(mode_)) { if (mode >= 1) { try_init(); } }
      inline ~storage_t() throw() { if (mode >= 0) { try_deinit(); } }
        // 1 - success, 0 - already initialized; -1 - failed to initialize, nothing changed.
      inline s_long try_init() throw() { if (inited) { return 0; } try { meta::construct_f<T, Aux>().f(ptr()); inited = true; return 1; } catch (...) {} return -1; }
      inline s_long try_init(const T& x) throw() { if (inited) { return 0; } try { new (ptr()) T(x); inited = true; return 1; } catch (...) {} return -1; }
        // 1 - success, 0 - was not initialized; -1 - destructor failed, so just set inited to false.
      inline s_long try_deinit() throw() { if (inited) { try { T* p = ptr(); p->~T(); inited = false; return 1; } catch (...) {} inited = false; return -1; } return 0; }
      inline operator T*() const throw() { return reinterpret_cast<T*>(&pl); }
      inline T* ptr() const throw() { return reinterpret_cast<T*>(&pl); }
      inline operator T&() const throw() { return reinterpret_cast<T&>(*ptr()); }
    };

    template<class T, bool is_const> class iterator_t : public yk_c::vecm::link1_t<T, is_const>, public std::iterator<std::random_access_iterator_tag, T>
    {
    public:
      typedef yk_c::s_long s_long; typedef yk_c::vecm vecm;
      typedef T t_value; typedef t_value value_type;
      typedef typename yk_c::meta::if_t<is_const, const t_value*, t_value*>::result  pointer;
      typedef typename yk_c::meta::if_t<is_const, const t_value&, t_value&>::result reference;
      typedef yk_c::vecm::link1_t<t_value, is_const> t_link;
      typedef typename t_link::t_ctnr t_ctnr;
      typedef std::random_access_iterator_tag iterator_category; typedef iterator_t iterator_type; typedef s_long difference_type;

      inline iterator_t() throw() {}
      inline iterator_t(t_ctnr& v) throw() : t_link(v) {} // end pos.
      inline iterator_t(const t_link& l) throw() : t_link(l) {}
      inline iterator_t(t_ctnr& v, s_long ind) throw() : t_link(v, ind) {}
      inline iterator_t(const iterator_t<T, false>& x) throw() : t_link(x) {}
      inline iterator_t(const iterator_t<T, true>& x) throw() : t_link(x) {}

      inline reference operator*() const throw() { return *this->_px; }
      inline pointer operator->() const throw() { return this->_px; }
      inline reference operator[](difference_type delta) const throw() { return *this->_pv->template pval_0u<t_value>(this->_i + delta); }
      inline iterator_type& operator++() throw() { this->incr(); return *this; }
      inline iterator_type& operator--() throw() { this->decr(); return *this; }
      inline iterator_type& operator+=(difference_type delta) throw() { this->move_by(delta); return *this; }
      inline iterator_type& operator-=(difference_type delta) throw() { this->move_by(-delta); return *this; }
      inline iterator_type operator++(int) throw() { iterator_type i = *this; this->incr(); return i; }
      inline iterator_type operator--(int) throw() { iterator_type i = *this; this->decr(); return i; }
      inline iterator_type operator+(difference_type delta) const throw() { iterator_type i = *this; i.move_by(delta); return i; }
      inline iterator_type operator-(difference_type delta) const throw() { iterator_type i = *this; i.move_by(-delta); return i; }
      inline difference_type operator-(const iterator_type& x) const throw() { return this->ind0() - x.ind0(); }
      inline bool operator==(const iterator_type& x) const throw() { return this->is_eq(x); }
      inline bool operator!=(const iterator_type& x) const throw() { return !this->is_eq(x); }
      inline bool operator>(const iterator_type& x) const throw() { return this->ind0() > x.ind0(); }
      inline bool operator<(const iterator_type& x) const throw() { return this->ind0() < x.ind0(); }
      inline bool operator>=(const iterator_type& x) const throw() { return this->ind0() >= x.ind0(); }
      inline bool operator<=(const iterator_type& x) const throw() { return this->ind0() <= x.ind0(); }
    };
    template<class T, bool b> iterator_t<T, b> operator+(typename iterator_t<T, b>::difference_type delta, const iterator_t<T, b>& x) throw() { iterator_t<T, b> i(x); i.move_by(delta); return i; }
//    namespace yk_c { template<class T, bool b> struct meta::type_equi<iterator_t<T, b>, meta::tag_construct> { typedef meta::tag_construct t_3; }; }
//    namespace yk_c { template<class T, bool b> struct meta::type_equi<iterator_t<T, b>, meta::tag_functor> { typedef meta::tag_functor t_3; }; }
  }
  template<class T, bool b> struct meta::type_equi<experimental::iterator_t<T, b>, meta::tag_construct> { typedef meta::tag_construct t_3; };
  template<class T, bool b> struct meta::type_equi<experimental::iterator_t<T, b>, meta::tag_functor> { typedef meta::tag_functor t_3; };
}

#endif
