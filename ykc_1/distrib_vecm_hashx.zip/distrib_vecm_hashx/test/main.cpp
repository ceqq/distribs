#define _test_common_PREINCL
  #include "_test_common.h"
#include "../vecm_hashx.h"
#include "_test_vecm_hashx.h"

int main(int argc, char** argv)
{
  bool is_full = !(argc >= 2 && argv[1][0] == 's' && argv[1][1] == 0);
  char* prnd0 = argc >= 3 ? argv[2] : 0;
  try { yk_tests::test_vecm_hashx<>().do_test(is_full, prnd0); } catch (...) { std::cerr << "main() catch(...): press any key\n"; while (!std::cin.get()){} return 1; }
  return 0;
}
