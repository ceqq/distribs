#ifndef __common_elem_ampavg_H
#define __common_elem_ampavg_H

#include "common_elem.h"

namespace ns_plhost
{
  typedef _samples_block_t<double> t_block_ampavg;
  typedef vnnqueue_t<t_block_ampavg> t_queue_baa;
}
namespace yk_c
{
  template<> struct bytes::type_index_t<ns_plhost::t_queue_baa> : cmti_base_t<ns_plhost::t_queue_baa, 2020, 3, 9, 13, -1> {};
  namespace { bytes::type_index_t<ns_plhost::t_queue_baa> __cmti_inst_ns_plhost__t_queue_baa; }
}


#endif
