=========================================================================================
  Readme for
    exmp_dispatcher_bulk_transfer
=========================================================================================

  This project tests transfer speed for large amount of binary data, via shared memory.
    The supplier and the consumer side may reside either in the same process (as different threads),
    or each in its own process.

========================================================================================================================

  Build notes.

    1. Ensure BMDX library downloaded and unpacked so that src_code folder was placed
      aside (at the same level with) src_examples folder.
    2. Choose one of bld_* folders with build scripts, most closely matching with your target system.
    3. Correct bld_*/bld script so that compiler paths in the script were correct for your system.
    4. Note. Almost all scripts contain instructions for two compilers, one of which is likely
      the main system compiler.
      If both compilers are installed, any of them may be chosen to build the executable, via bld script arguments.
      E.g. "./bld 1" invokes compiler 1, "./bld 2" invokes compiler 2.
    5. Run the chosen script in its own directory (e.g. ./bld).
      If all goes well, it creates the executable in the same directory.

    (6). Alternatively, the project may be built with Qt/qmake.
      Use exmp_bulk_win.pro or exmp_bulk_nix.pro depending on the type of your system.
      Note that certain compiler paths in the project files may require correction to match with your system.
      The resulting executable is placed into out_bin folder at one level with src_examples folder.

========================================================================================================================

  Running the example.

    Depending on the target system:

      a) To test in-process transfer:
        ./bulk
          or
        bulk.exe

      b) To test inter-process transfer:
        ./bulk ab
          or
        bulk.exe ab
        This way, the program automatically runs the second process, which will receive the data.
        The second process exits as soon as it receives all the data and reports back on the result.

      c) An example for "manually" running the inter-process transfer test:
        1. Run "./bulk b" in one terminal window.
        2. At once (<3 s) run "./bulk a" in another terminal window.

        Note A. The order should be (b, a) because, by example design, the recipient is able to wait
          for the supplier for human-noticeable time, but not vice versa.

        Note B. Both processes may be also run one from one terminal window, e.g.
          ./bulk b & ./bulk a
