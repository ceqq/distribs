#include "../../src_code/bmdx_main.h"
#include <iostream>

using namespace std;
using namespace bmdx;

struct __test_op_timeout_handler
{
  double dto_ms, t0;
  __test_op_timeout_handler(double dto_ms_) { dto_ms = dto_ms_; reset(); }
  operator bool() const { if (clock_ms() - t0 >= dto_ms) { return true; } sleep_mcs(100); return false; }
  void reset() { t0 = clock_ms(); }
};

struct test_thread_a : threadctl::ctx_base
{
  typedef arrayref_t<char> t_stringref;
  void _thread_proc() { this->exec(*pdata<unity>()); }
  void exec(unity& args)
  {
    s_long res; unity mr;
    __test_op_timeout_handler to(7000);
    std::ostream& log = +args[1]; (void)&log;
    s_long& res_th = +args[2]; res_th = -2;
    o_iptr_t<i_dispatcher_mt> a = args[3].pinterface<i_dispatcher_mt>();
    vec2_t<cref_t<t_stringref> >& data = +args[4];
    unity ms = args[5];
      unity& ms_src_sl = ms.hash("src");
      unity& ms_trg_sl = ms["trg"][ms["trg"].arrub()];
      unity& ms_text = ms.hash("text");
    const s_long flags1a = args[6].vint_l();
    double& dtms = +args[9];
    s_ll flags = +args / 10 / 0ll;
    console_io cons(!(flags & 1));
    double t0 = clock_ms();

      // Sending the data to trg, specified by parent thread.
    ms_src_sl = "po_1"; (void)ms_trg_sl; ms_text.clear();
    for (s_long i = 0; i < data.n(); ++i)
    {
      res = a->msend(ms, data[i], flags1a);
      if (res != 1)
      {
        if (i == 0 && clock_ms() - t0 < 200) { sleep_mcs(10000); i = -1; continue; } // this gives the consumer some time to connect, when it's run near-simultaneously with supplier (see test :: exec)
        res_th = -__LINE__; return;
      }
    }

      // Waiting for feedback from another thread.
      //  NOTE The timeout is increased for tests on virtual machines with slow shared memory simulation.
    to.dto_ms = 45000;
    to.reset(); do { res = a->mget("qi_feedback", mr); } while (res == 0 && !to && cons.ugetch() != 0x1b); if (res != 1) { res_th = -__LINE__; return; }
    unity& ret = mr["text"];
    if (!(ret.isArray() && ret[1] == "test succeeded")) { res_th = -__LINE__; return; }

    dtms = ret[2].vfp();
    res_th = 1;
  }
};
struct test_thread_b : threadctl::ctx_base
{
  typedef arrayref_t<char> t_stringref;
  void _thread_proc() { this->exec(*pdata<unity>()); }
  void exec(unity& args)
  {
    __test_op_timeout_handler to(7000);
    s_long res; unity mr;
    std::ostream& log = +args[1]; (void)&log;
    s_long& res_th = +args[2]; res_th = -2;
    o_iptr_t<i_dispatcher_mt> b = args[3].pinterface<i_dispatcher_mt>();
    const s_long nmsgs1 = args[4].vint_l();
    unity ms = args[5];
      unity& ms_src_sl = ms.hash("src");
      unity& ms_trg_sl = ms["trg"][ms["trg"].arrub()];
      unity& ms_text = ms.hash("text");
    const s_long flags1b = args[6].vint_l();
    const s_ll npacks = args[7].vint();
    const s_ll nbpack = args[8].vint();
    s_ll flags = +args / 10 / 0ll;
    double dtms = 0;
    vec2_t<cref_t<t_stringref> > data;
    cref_t<t_stringref> att;
    console_io cons(!(flags & 1));


    if (1)
    {
      double t1 = 0, t2 = 0;
      for (s_long i = 0; i < nmsgs1; ++i)
      {
        if (i == 1) { t1 = clock_ms(); } // the first data pack (i == 0) receival time is not counted in transfer speed meas., because it includes lag between threads
        to.reset(); do { res = b->mget("qi_1", mr, &att, flags1b); } while (res == 0 && !to && cons.ugetch() != 0x1b); if (res != 2) { res_th = -__LINE__; return; }
          if (!(att->n() == nbpack && att->opsub(nbpack - 1) == 1 + i % npacks)) { res_th = -__LINE__; return; } // check one byte of data for correctness
          data.push_back(att);
      }
      t2 = clock_ms();
      dtms = t2 - t1;
    }

      // NOTE Tracking is necessary because if running as secondary process (peer 2),
      //  the feedback message gets into the main process (peer 1) not immediately.
      //  Internal threads of shmqueue_s and dispatcher_mt take some time to push/pop the serialized message.
      //  Successful tracking report tells that the message is already inside the peer 1 process.
    cref_t<i_dispatcher_mt::tracking_info> trk; if (!trk.cm_create0(0, 0, 1)) { res_th = -__LINE__; return; }
    ms_src_sl = "po_feedback"; ms_trg_sl = "qi_feedback"; ms_text = unity().array("test succeeded", dtms);
    res = b->msend(ms, cref_t<t_stringref>(), 0, trk); if (res != 1) { res_th = -__LINE__; return; }
        to.reset(); do { res = (s_long)trk->state; } while (res <= 1 && !to && cons.ugetch() != 0x1b); if (res != 3) { res_th = -__LINE__; return; }

    res_th = 1;
  }
};

struct test
{
  typedef arrayref_t<char> t_stringref;

    // Common part.
  bool run_a, run_b, run_prc2, b_peer2;
  s_ll Npacks, Nbpack, Npacksrep;
  s_long fl_anlo;
  wstring __pn_root, pname1, pname2;

    // Data supplier part.
  vec2_t<cref_t<t_stringref> > data;
  wstring cfga;
  cref_t<dispatcher_mt> da;
    unity prxa, argsa; // NOTE must be declared after da, to avoid deadlock on exit
  s_long res_a, fla; double dtms;

    // Data consumer part.
  wstring cfgb;
  cref_t<dispatcher_mt> db;
    unity prxb, argsb; // NOTE must be declared after db, to avoid deadlock on exit
  s_long res_b, flb;

  test()
  {
      // Common part.
    run_a = run_b = 1; run_prc2 = 0; b_peer2 = 0;

    Npacks = 3; Nbpack = 20 * 1024 * 1024; Npacksrep = 50;

    fl_anlo = 0;
      // fl_anlo |= dispatcher_mt_flags::use_chsbin; // this flag decreases transfer speed (up to 8x from max. possible)
      fl_anlo |= dispatcher_mt_flags::anlo_att; // this flag (must be set in both peers) minimizes binary data copying and thus increases transfer speed to max. possible

    __pn_root = L"test_bmdx_unity_";
    pname1 = __pn_root + L"supplier";
    pname2 = __pn_root + L"consumer";


      // Data supplier part.
    cfga = L"=|thread1|slots; po_1; qi_1; qi_feedback";
    res_a = 0; fla = fl_anlo; dtms = 0;

      // Data consumer part.
    flb = dispatcher_mt_flags::get_hashlist | fl_anlo;
    cfgb = L"=|thread1|slots; po_feedback; qi_1";
    res_b = 0;
  }

  int exec()
  {

    try {

      if (run_a)
      {
          // Supplier: generate some data.
        try {
          for (int i = 0; i < Npacks; ++i) { data.push_back(i_dispatcher_mt::make_rba_z(Nbpack)); if (!data.back()) { return -__LINE__; } t_stringref d = data.back().ref(); for (int j = 0; j < Nbpack; j += 511) { d[j] = char(j); } d[Nbpack - 1] = i + 1; }
          for (s_ll i = Npacks; i < Npacksrep; ++i) { data.push_back(data[s_long(i % Npacks)]); }
        } catch (...) { return -__LINE__; }

          // Supplier: prep. worker thread.
        da.create2(0, pname1, cfga);
        da->new_proxy(prxa, "thread1");
          if (!prxa.isObject()) { return -__LINE__; }
        argsa.array(unity(cerr, false), unity(res_a, false), prxa, unity(data, false), paramline().decode(L"trg = |LM|" + pname2 + L"|thread1|qi_1", 0), fla, Npacks, Nbpack, unity(dtms, false), b_peer2 ? 1 : 0);
      }

      bool run_b_inpr = run_b && !run_prc2; // run consumer thread inside the current process
      if (run_b_inpr)
      {
          // Consumer: prep. worker thread.
        db.create2(0, pname2, cfgb);
        db->new_proxy(prxb, "thread1");
          if (!prxb.isObject()) { return -__LINE__; }
        argsb.array(unity(cerr, false), unity(res_b, false), prxb, Npacksrep, paramline().decode(L"trg = |LM|" + pname1 + L"|thread1|qi_feedback", 0), flb, Npacks, Nbpack, unity(), b_peer2 ? 1 : 0);
      }

      threadctl tb;
      if (run_b_inpr && !tb.start_auto<test_thread_b>(argsb)) { return -__LINE__; }

      processctl pb;
      if (run_prc2 && !pb.launch(unity(cmd_myexe()).vcstr(), "b2")) { return -__LINE__; }

      threadctl ta;
      if (run_a && !ta.start_auto<test_thread_a>(argsa)) { return -__LINE__; }

      console_io cons(!b_peer2);
      while ((run_a && ta) || (run_b_inpr && tb) || (run_prc2 && pb.is_running()))
      {
        if (cons.ugetch() == 0x1b) { cerr << "ESC pressed. Exiting.\n"; return -__LINE__; }
        sleep_mcs(10000);
      }

      bool b_good = true;
      if (run_a && !(res_a == 1 && dtms > 0)) { b_good = false; cerr << "ERR res_a, dtms: " << res_a << " " << dtms << "\n"; }
      if (run_b_inpr && !(res_b == 1)) { b_good = false; cerr << "ERR res_b: " << res_b << "\n"; }
      if (!b_good) { return -__LINE__; }

      if (run_a) { cout << "dispatcher_mt po-->qi perf., MB/s " << s_ll(Nbpack) * (Npacksrep - 1) / (dtms / 1000) / (1024 * 1024) << "\n"; }

      return 1;
    } catch (...) { return -__LINE__; }
  }

};

int main(int argc, char** argv)
{
  if (argc < 2 || !((argv[1][0] == 'a' || argv[1][0] == 'b')))
  {
    cout << "Bulk transfer test. Usage:\n"
      " bulk  -- tests supplier/consumer in the same process.\n"
      " bulk a  -- runs supplier only (be sure that consumer is just run separately)\n"
      " bulk b -- runs consumer only (and quickly, in 5s, run supplier as well)\n"
      " bulk ab -- tests supplier/consumer in two processes (the second is run automatically).";
    if (argc >= 2) { return 0; }
  }


  test t;
    t.run_a = argc < 2 || argv[1][0] == 'a';
    t.run_b = argc < 2 || argv[1][0] == 'b' || (argv[1][0] == 'a' && argv[1][1] == 'b');
    t.run_prc2 = argc >= 2 && (argv[1][0] == 'a' && argv[1][1] == 'b');
    t.b_peer2 = argc >= 2 && (argv[1][0] == 'b' && argv[1][1] == '2');

  if (t.run_a || t.run_b) { cout << "Running...\n"; }

  int res = t.exec();
  if (res == 1) { return 0; }
  cerr << "ERR t.exec(): " << res << "\n";
  // cin.get();
  return -res;
}
