#include <stdio.h>
#include "../../../src_code/bmdx_cpiomt.h"

namespace utils_audio
{

using bmdx_meta::s_ll;
using bmdx_meta::s_long;

enum ESampleFormat
{
  _fmtsmp_invalid = 0,
  fmtsmp_int16, // sample16 (factual type may vary)
  fmtsmp_int24, // struct sample24
  fmtsmp_int32, // sample32, s_long (factual type may vary)
  fmtsmp_float32, // sample32f, float
  _fmtsmp_end
};

typedef bmdx_meta::find_size_n<2, signed int, signed short, wchar_t>::result sample16;
typedef s_long sample32;
typedef float sample32f;
struct sample24 { typedef unsigned char uchar; uchar x[3]; sample32f le_to_32f() const { return float(double((s_long(uchar(x[2])) << 24) | (s_long(uchar(x[1])) << 16) | (s_long(uchar(x[0])) << 8)) / double(0x80000000ll)); } };

inline s_long bpsmp(s_long fmtsmp) { static const s_long n[_fmtsmp_end] = { 0, 2, 3, 4, 4 }; return n[fmtsmp]; }

namespace wav_reader_v1
{

using namespace bmdx_str::words;

struct wav_reader
{
    // Static checks.
  bool sup_rate(s_long rate) const throw() { return rate >= 100 && rate <= 768000; }
  bool sup_nch(s_long nch) const throw() { return nch >= 1 && nch <= 256; }
  bool sup_fmt(s_long fmtsmp) const throw() { return fmtsmp >= fmtsmp_int16 && fmtsmp <= fmtsmp_float32; }

    // (Static.) Limit value to [-1..1].
  sample32f limit11(sample32f x) const throw() { if (x > 1) { return 1; } if (x < -1) { return -1; } return x; }
  void limit11(sample32f* x) const throw() { if (!x) { return; } *x = limit11(*x); }

    // Static conversions. Result is in [-1..1].
  void conv_le16_to_32f(const void* src, void* dest) const throw() { *((sample32f*)dest) = float(double(sample16(le2(src, 0))) / double(0x8000ll)); }
  void conv_le24_to_32f(const void* src, void* dest) const throw() { *((sample32f*)dest) = ((const sample24*)src)->le_to_32f(); }
  void conv_le32_to_32f(const void* src, void* dest) const throw() { *((sample32f*)dest) = float(double(sample32(le4(src, 0))) / double(0x80000000ll)); }
  void conv_le32f_to_32f(const void* src, void* dest) const throw() { *((sample32f*)dest) = (float)le4(src, 0); }

  wav_reader() { _nch = 1; _fmtsmp = fmtsmp_float32; _rate = 96000; _data0 = 0; _nbytes = 0;  }

  bool fs_is_open() const throw() { return _fs.is_open(); }

  void fs_close() throw() { if (_fs.is_open()) { _fs.close(); } _nbytes = 0; }

    // Data format for the open file, or default values (1, fmtsmp_float32, 96000, 4) if the file is not open.
  s_long nch() const throw() { return _nch; } // number on channels in wav (>=1)
  s_long fmtsmp() const throw() { return _fmtsmp; } // ESampleFormat
  s_long rate() const throw() { return _rate; } // wav sampling rate, Hz (number of frames per second)
  s_long nbfr() const throw() { return bpsmp(_fmtsmp) * _nch; } // number of bytes in a frame

    // Returns:
    //  >= 0 the number of audio frames in the open file.
    //  0: file stream is not open.
  s_ll nfr() const throw()
  {
    if (!_fs.is_open()) { return 0; }
    s_ll n = (_nbytes - _data0) / nbfr();
    if (n >= 0) { return n; }
    return 0;
  }

    // Returns:
    //  >=0: index of the next frame that will be read.
    //  -1: wrong position.
    //  -3: file stream is not open.
  s_ll fs_pos() const throw()
  {
    if (!_fs.is_open()) { return -3; }
    s_ll x2 = _fs.tell(); if (x2 < 0) { return -1; }
    s_ll x3 = (x2 - _data0) / nbfr();
    return x3 >= 0 ? x3 : -1;
  }

    // Opens or reopens a wav file.
    // Returns:
    //  1: success. is_open() becomes true.
    //  -1: empty or null filename.
    //  -3: failed to open, read, seek the file.
    //  -4: file exists, but has wrong contents: a) zero length, b) broken header.
    //  -5: file exists, but has unrecognized data or header format.
  s_long fs_open(const char* pfilename) throw()
  {
    _fs.close();
    if (!pfilename || *pfilename == '\0') { return -1; }

    _nch = 1;
    _fmtsmp = s_long(fmtsmp_float32);
    _rate = 96000;
    _data0 = 0;
    _nbytes = 0;

    _fs.open(pfilename, false); if (!_fs.is_open()) { return -3; }
    _fs.seek(0); if (_fs.result() != 1) { _fs.close(); return -3; }

    unsigned char hdr1[256];
    _fs.read(hdr1, 20);

    if (_fs.result() == 1)
    {
      bool b = true;

      b = b && le4(hdr1, 0) == 0x46464952;
      b = b && le4(hdr1, 8) == 0x45564157;
      b = b && le4(hdr1, 12) == 0x20746d66;
      s_long nhdr2 = le4(hdr1, 16); if (!b || nhdr2 < 16 || 20 + nhdr2 + 8 > 256) { _fs.close(); return -5; }

      _fs.read(hdr1 + 20, nhdr2 + 8); if (_fs.result() != 1) { _fs.close(); return -4; }

      b = le4(hdr1, 20 + nhdr2) == 0x61746164;
      b = b && sup_rate(le4(hdr1, 24)); // supported smp. rate range

      s_long nch2 = le2(hdr1, 22);
      s_long nbits = le2(hdr1, 34);
      s_long fmt2 = le2(hdr1, 20);
      s_long rate2 = le4(hdr1, 24);
      if (nbits == 16 && fmt2 == 1) { fmt2 = fmtsmp_int16; }
        else if (nbits == 24 && fmt2 == 1) { fmt2 = fmtsmp_int24; }
        else if (nbits == 32 && fmt2 == 1) { fmt2 = fmtsmp_int32; }
        else if (nbits == 32 && fmt2 == 3) { fmt2 = fmtsmp_float32; }
        else { b = false; }

      b = b && sup_nch(nch2) && sup_fmt(fmt2) && sup_rate(rate2);
      if (!b) { _fs.close(); return -5; }

      _nch = nch2; _fmtsmp = fmt2; _rate = rate2;
      _data0 = 20 + nhdr2 + 8;

      if (1) { const s_ll n = (s_ll(le4(hdr1, 20 + nhdr2 + 4)) & 0xffffffffll) + _data0; _nbytes = n; }
      const s_ll nbfr = _nch * bpsmp(_fmtsmp);

      _nbytes = (((_nbytes - _data0) / nbfr) * nbfr) + _data0;
    }
    else { _fs.close(); return -4; }

    return 1;
  }

    // pos_fr - 0-based target frame number.
    // Returns:
    //  1: position is set successfully.
    //  -1: position is out of file bounds.
    //  -2: seek error.
    //  -3: file stream is not open.
  s_long fs_set_pos(s_ll pos_fr) throw()
  {
    if (!_fs.is_open()) { return -3; }
    s_ll x = _data0 + pos_fr * nbfr(); if (!(x >= _data0 && x <= _nbytes)) { return -1; }
    _fs.seek(x);
    s_ll x2 = _fs.tell();
    s_ll x3 = (x2 - _data0) / nbfr(); if (x3 < 0) { x3 = -1; }
    return x3 >= 0 && x2 == x ? 1 : -2;
  }

    // Reads raw frames data, starting from the current position.
    // dest must be at least nfr * nbfr() bytes long.
    // Returns:
    //  >=0: number of frames read. May be less than nfr if read beyond file end.
    //  -1: nfr < 0, or dest == 0.
    //  -2: read error.
    //  -3: file stream is not open.
  s_ll fs_read_raw(s_ll nfr, char* dest) throw()
  {
    if (nfr < 0 || dest == 0) { return -1; }
    if (!_fs.is_open()) { return -3; }

    s_ll pos1 = fs_pos(); if (pos1 < 0) { return -2; }
    s_ll nmax = this->nfr() - pos1;
    if (nmax <= 0) { return 0; }
    if (nfr > nmax) { nfr = nmax; }

    if (nfr == 0) { return 0; }

    size_t n = nfr * nbfr();
    if (s_ll(n) != nfr * nbfr()) { return -1; }

    n = _fs.read(dest, n);
      if (_fs.result() != 1) { return -2; }
    return n / nbfr();
  }

    // Reads frames data, starting from the current position,
    //   then converts it to float, normalized to [-1..1].
    // dest must be at least nfr * nch() floats long.
    // Returns:
    //  >=0: number of frames read. May be less than nfr if read beyond file end.
    //  -1: nfr < 0, or dest == 0.
    //  -2: read error.
    //  -3: file stream is not open.
  s_ll fs_read_32f(s_ll nfr, float* dest) throw()
  {
    if (nfr < 0 || dest == 0) { return -1; }
    if (!_fs.is_open()) { return -3; }

    s_ll pos1 = fs_pos(); if (pos1 < 0) { return -2; }
    s_ll nmax = this->nfr() - pos1;
    if (nmax <= 0) { return 0; }
    if (nfr > nmax) { nfr = nmax; }

    if (nfr == 0) { return 0; }

    size_t n = nfr * nbfr();
    if (s_ll(n) != nfr * nbfr()) { return -1; }

    n = _fs.read(dest, n);
      if (_fs.result() != 1) { return -2; }
    size_t q = size_t(bpsmp(_fmtsmp));
    n = n / q; // number of sample values read
    switch (_fmtsmp)
    {
      case fmtsmp_int16: { for (s_ll i = s_ll(n) - 1; i >= 0; --i) { conv_le16_to_32f((char*)dest + (i << 1), dest + i); } break; }
      case fmtsmp_int24: { for (s_ll i = s_ll(n) - 1; i >= 0; --i) { conv_le24_to_32f((char*)dest + (i * 3), dest + i); } break; }
      case fmtsmp_int32: { for (s_ll i = s_ll(n) - 1; i >= 0; --i) { conv_le32_to_32f(dest + i, dest + i); } break; }
      case fmtsmp_float32: { s_long i = 1; if (!*(char*)&i) { for (s_ll i = s_ll(n) - 1; i >= 0; --i) { conv_le32f_to_32f(dest + i, dest + i); } } break; }
      default: return -2;
    }
    return n / nch();
  }

private:
  bmdx::file_io _fs;
  s_long _nch, _fmtsmp, _rate;
  s_ll _data0, _nbytes;
};

}

}

