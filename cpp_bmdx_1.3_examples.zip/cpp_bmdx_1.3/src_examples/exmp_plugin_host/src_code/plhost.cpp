#include "../../../src_code/bmdx_main.h"
#include <iostream>

using namespace std;
using namespace bmdx;

  // This flag variable, when set to 1 (or != 0) by any plugin, indicates that the host should exit.
static s_long gfl_exit = 0;

struct plugin_ctx
{
  unity::mod_handle mh; // NOTE when clearing or overwriting mh, ensure th, supplier, cfg_inst, cfg_pl, ret_code to be cleared or recreated to belong to the current module
  unity cfg_pl; // user-defined per-plugin-type configuration
  unity cfg_inst; // user-defined per-plugin-instance configuration
  unity para; // per-plugin-instance configuration, passed into plugin instance for its initialization
  unity inst_interface; // variable, returned by the plugin instance, with any form of information or interface for use in the dependent plugins

  plugin_ctx() {}
  ~plugin_ctx() { clear(); }

  void clear() { cfg_inst.recreate(); cfg_pl.recreate(); mh.clear(); }
};

int main(int argc, char** argv)
{



  // 1. Load plugins configuration.

  unity cfg;
  hashx<unity, plugin_ctx> pls;
  try {
    string fnp_cfg = argc >= 2 ? argv[1] : "plhost.cfg";
    unity s = file_utils().load_string("text local8bit utf16le utf16be", fnp_cfg); if (s.isEmpty()) { return 0; }
    cfg = paramline().decode_tree(s.vstr());
  } catch (...) { return 1; }



  // 2. Eval. plugin instance dependency tree, check for absence of loops.

  try {
    const unity* p = cfg.path("plugins"); if (!(p && p->isHash() && p->hashS_c())) { return 0; }
    hashx<unity, hashx<unity, int> > hdep;
    hashx<unity, unity> hcfg_inst;
    hashx<unity, unity> hcfg_pl;
    for (s_long i = 1; i <= p->hashS_c(); ++i)
    {
      const unity* p2 = p->hashi_c(i).path("instances");
      if (p2 && p2->isHash()) { for (s_long j = 1; j <= p2->hashS_c(); ++j) {
        unity k_inst = p->hashi_key_c(i).vstr() + L"." + p2->hashi_key_c(j).vstr();

        (void)hdep[k_inst];
        hcfg_inst[k_inst] = p2->hashi_c(j);
        hcfg_pl[k_inst] = +cfg / (L"plugins|" + p->hashi_key_c(i).vstr()) / unity();

        const unity* pdep = p2->hashi_c(j).path("depends");
        if (pdep && pdep->isArray()) { for (s_long j2 = 1; j2 <= pdep->arrub(); ++ j2) { (void)hdep[k_inst][(*pdep)[j2].vstr()]; } }
      } }
    }
    while (hdep.n())
    {
      bool b_loop = true;
      unity k;
      for (s_long i = 0; i < hdep.n(); ++i)
      {
        k = hdep(i)->k;
        if (hdep(i)->v.n() == 0)
        {
          b_loop = false;
          for (s_long j = 0; j < hdep.n(); ++j)  { hdep(j)->v.remove(k); }
          hdep.remove_i(i);
          break;
        }
      }
      if (b_loop) { return 3; }
      pls[k].cfg_inst = hcfg_inst[k];
      pls[k].cfg_pl = hcfg_pl[k];
    }
  } catch (...) { return 2; }



  // 3. Load plugin modules.

  if (1)
  {
    s_long ind1 = -1;
    for (s_long i = 0; i < pls.n(); ++i)
    {
      plugin_ctx& c = pls(i)->v;
      try {
        unity bin = +c.cfg_pl / "bin" / unity(L"");
        if (bin.isArray())
        {
          for (s_long j = 1; j <= bin.arrub(); ++j)
          {
            string path = bin[j].vcstr();
            if (file_utils().is_valid_path(path)) { c.mh = unity::mod(path.c_str(), true); }
            if (c.mh) { break; }
          }
        }
        else
        {
          string path = bin.vcstr();
          if (file_utils().is_valid_path(path)) { c.mh = unity::mod(path.c_str(), true); }
        }
        if (!c.mh) { cerr << "ERR Could not load plugin with the following paths: " << bin.vcstr() << endl; ind1 = i; break; }
      } catch (...) { ind1 = i; break; }
    }
    if (ind1 >= 0) { return 4 + 100 * ind1; }
  }



  unity __rphase;
    if (!__rphase.objt<s_long>(1)(0)) { return 2; }
  s_long& host_phase = __rphase.ref<s_long>();

  int err_state = 1;
  try { do { // once



    // 4. Initialize each plugin instance -- step 1: before all upward dependencies are initialized.

    for (s_long i = 0; i < pls.n(); ++i)
    {
      plugin_ctx& c = pls(i)->v;

      c.para = c.cfg_pl;
      paramline().merge(c.para, c.cfg_inst);
      c.para.hash("__inst_name") = pls(i)->k;
      c.para.hash("__host_phase") = __rphase;
      c.para.hash("__gfl_exit").set_obj(gfl_exit, false);
      unity& hdep = c.para.hash("depends"); hdep.hash_clear(1);

      const unity* pdep = c.cfg_inst.path("depends");
      if (pdep && pdep->isArray()) { for (s_long i = 1; i <= pdep->arrub(); ++i) { wstring k = pdep->vstr(i); if (pls.find(k)) { hdep.hash(k); } } }

      c.para.hash("__f") = 1;
      s_long res_rq = c.mh.request(c.para, c.inst_interface);
        if (res_rq != 1) { cerr << "ERR c.mh.request(__f == 1): " << res_rq << "; plugin: " << pls(i)->k.vcstr() << endl; err_state = 2; break; }
    }
    if (err_state == 2) { break; }



    // 5. Initialize each plugin instance -- step 2: all upward dependencies are already initialized and available for communication.

    for (s_long i = 0; i < pls.n(); ++i)
    {
      plugin_ctx& c = pls(i)->v;
      c.para.hash("__interface") = c.inst_interface;
      unity& hdep = c.para.hash("depends");
      for (s_long i = hdep.assocl_first(); i != hdep.assocl_noel(); i = hdep.assocl_next(i)) { hdep.assocl(i) = pls[hdep.assocl_key(i)].inst_interface; }

      c.para.hash("__f") = 2;
      unity __rqretv;
      s_long res_rq = c.mh.request(c.para, __rqretv);
        if (res_rq != 1) { cerr << "ERR c.mh.request(__f == 2): " << res_rq << "; plugin: " << pls(i)->k.vcstr() << endl; err_state = 2; break; }
    }
    if (err_state == 2) { break; }




    // 6. Normal working state.
    //  Possible stop conditions:
    //    a) ESC pressed.
    //    b) all references to host phase variable are released by plugin instances.
    //    c) global exit flag (gfl_exit) is set by any of the plugins.

    err_state = 0;
    if (1)
    {
      console_io cons;
      while (1)
      {
        host_phase = 1;
        if (cons.ugetch() == 0x1b) { break; }
        if (gfl_exit != 0) { break; }
        if (__rphase.objRefInfo().rc_strong() <= 1 + pls.n()) { break; }
        sleep_mcs(10000);
      }
    }
  } while (false); } catch (...) {}



  // 7. Wait for all plugins to have exited.

  for (s_long i = 0; i < pls.n(); ++i) { plugin_ctx& c = pls(i)->v; c.para.clear(); c.inst_interface.clear(); }
  while (1)
  {
    host_phase = 2;
    if (__rphase.objRefInfo().rc_strong() <= 1) { break; }
    sleep_mcs(10000);
  }
  return err_state;
}
