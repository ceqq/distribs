#include "common_elem_samples.h"
#include "common_elem_ampavg.h"
#include "../../../src_code/bmdx_main.h"

using namespace std;
using namespace bmdx;
using namespace bmdx_str::conv;

struct __t_static_storage_selector {};
typedef svf_m_t<hashx<unity, unity>, __t_static_storage_selector> t_static_storage;

  // Processor's implementation of struct i_supplier.
namespace bmdx
{
  struct t_queue_supplier_impl {};

  template<>
  struct o_iimpl<t_queue_supplier_impl, ns_plhost::i_supplier> : o_ibind<t_queue_supplier_impl, ns_plhost::i_supplier>, ns_plhost::i_supplier
  {
    virtual __t_i* __pMyI() { return this; }
    virtual void __itf_after_construct(s_long flags, o_itfset_base* src) { (void)flags; (void)src; }
    virtual void __itf_before_destroy(s_long flags) { (void)flags; }

      // name must be string (e.g. dependent plugin instance name).
      // args are ignored, should be empty.
    virtual unity queue_create(const unity& name, const unity& args)
    {
      (void)args;
      try {
        if (!name.isString()) { return unity(); }
        typename t_static_storage::L __lock; if (!__lock.b_valid()) { return unity(); }
        t_static_storage s_hqueues;
        hashx<unity, unity>& h = s_hqueues.rxai0(); // rxai0 makes a static variable, with automatic initialization (0 args.)
        unity& rq = h[name];
          if (!rq.isEmpty()) { return unity(); }
        rq.objt<ns_plhost::t_queue_baa>(0)();
        return rq;
      } catch (...) {}
      return unity();
    }
  };
}

namespace ns_plhost
{

struct th_processor : threadctl::ctx_base
{
  void _thread_proc()
  {
    // NOTE The processor plugin instance (thread) is connected to 1 supplier instance,
    //    and receives data through 1 configured channel.
    //    After processing, it in turn supplies the results (averaged amplitude) to multiple consumers.


    // ========================================
    // During plugins initialization.
    // ========================================

      const unity& para = *pdata<unity>();
      unity __rphase = para["__host_phase"]; // this local object ensures that phase variable will exist at least until the current thread exits
      s_long& host_phase = __rphase.ref<s_long>();

      wstring inst_name = +para / "__inst_name" / L""; if (inst_name.empty()) { return; }

      const double tavg_s = bmdx_minmax::myffrange_lb((+para / "t_avg_ms" / 100.) / 1000, 1.e-6, 86400); // averaging period for data; dflt. 0.1 s

      const unity* pdep = para.path("depends"); if (!pdep) { return; }
      o_iptr_t<i_supplier> psup = pdep->hashi_c(1).pinterface<i_supplier>(); if (!psup) { return; }
      const s_ll ichn = +para / "chn" / s_long(0);
      unity __q = psup->queue_create(inst_name, ichn);
      t_queue_bs* qbsamples = unity::o_api(&__q[2]).pobj<t_queue_bs>(0x64); if (!qbsamples) { return; }

      while (host_phase == 0)
      {
        // if (b_stop()) { return; } // not expected to be true because the thread is detached
        sleep_mcs(10000);
      }
      if (host_phase != 1) { return; }

    // ========================================
    // During normal work.
    // ========================================

        // Loop:
        //  1. Collect each N samples (according to t_avg_ms cfg. arg.).
        //  2. Calc avg. value.
        //  3. Push avg. value into all output queues.

        // NOTE For example simplicity, any unexpected return from the main loop does not notify dependent plugins.
      bool b_smp1 = true;
      t_block_ampavg baa;
      baa.ismp = 0; baa.t_s = 0; baa.smprate = 1 / tavg_s;
      s_ll curr_ismp = 0; double curr_time = 0; double curr_avg = 0; s_ll curr_navg = 0;
      bool b_has_avg = false;
      bool b_last = false;
      while (1)
      {
        // if (b_stop()) { return; } // not expected to be true because the thread is detached
        if (host_phase == 2) { return; }


        // NOTE For example simplicity, possible failures (e.g. bad alloc.) in the below queue push/pop operations are ignored.
        //    In the real DSP code, they should have been processed such that client plugin instances
        //    did not lose synchronization on getting the next successful portion of data after such a failure.


        while (qbsamples->navl() > 0)
        {
          const t_block_samples& bs = qbsamples->front();
          if (bs.flags & 1) { b_last = true; }
          if (b_smp1) { b_smp1 = false; baa.t_s = curr_time = bs.t_s; }

          s_ll j = 0;
          do
          {
            if (j < bs.samples.n()) { curr_navg += 1; curr_avg += std::fabs(bs.samples[j]); }

            bool b_window_end = curr_navg >= tavg_s * bs.smprate;
            if (b_window_end || (b_last && j >= bs.samples.n() - 1))
            {
              b_has_avg = true;
              if (curr_navg > 0) { curr_avg /= curr_navg; }
              baa.samples.append_1(curr_avg);
              if (b_last) { baa.flags |= 0x1; }
              curr_avg = 0; curr_navg = 0; curr_ismp += 1; curr_time = bs.t2_s(j);
            }
          } while (++j < bs.samples.n());

          qbsamples->pop_1();
          if (b_last) { break; }
        }

        if (b_has_avg)
        {
            // Get a working copy of the current set of queues (queues are held by reference).
          hashx<unity, unity> queues;
          try { typename t_static_storage::L __lock; if (__lock.b_valid()) { queues.hashx_copy(t_static_storage().rx(), 0); } } catch (...) {}

          for (s_long i = 0; i < queues.n(); ++i)
          {
            t_queue_baa* q = queues(i)->v.objPtr<t_queue_baa>();
            if (q) { q->push_1(baa); }
          }
          b_has_avg = false;
          baa.samples.clear();
          baa.ismp = curr_ismp;
          baa.t_s = curr_time;
        }
        if (b_last) { break; }

        sleep_mcs(5000);
      }
  }
};

}

  // ========================================
  // Plugin instance creation.
  // ========================================
  //
  //  DESCRIPTION
  //
  //    The plugin instance creation code (bmdx_mod_request) is typical for all plugins in the example.
  //
  //    It is called two times per plugin instance with
  //      (*ppara)["__f"] ==
  //          1: instance initialization, step 1.
  //              Upward dependencies are not resolved yet.
  //              The current instance should return via *pretval
  //              an application-defined object, interface or other information,
  //              that helps dependent plugins to communicate with the current instance.
  //              The format of the above is application-defined.
  //          2: instance initialization, step 2.
  //              All upward dependencies are resolved, and initialized by step 1 above.
  //              The current instance may call any of the influencing instances as necessary,
  //              and should not return anything via *pretval.
  //
  //    NOTE The sequence of plugin instance creation calls at each of the two steps is how they are listed in plugin host configuration file,
  //      which is generally different from sequence of dependencies.
  //
  //  INPUT (*ppara)
  //
  //    ["__f"]: see "DESCRIPTION" above.
  //    ["__inst_name"'] == <NAME>. NAME: full instance name in the form <plugin name>.<instance name>
  //    ["__host_phase"].ref<s_long>() ==
  //        0: during initialization,
  //        1: during normal operation,
  //        2: during exit (all plugin instances must exit when see phase == 2).
  //        This flag is global (single variable for all plugins).
  //        Each plugin instance should store a copy of this variable until it exits,
  //        for plugin host to be able to determine by ref. counting when all instances have exited.
  //    ["__gfl_exit"].ref<s_long>():
  //        ref. to s_long gfl_exit variable.
  //        Any plugin should set it to 1 if wants whole application to exit.
  //        This flag is global (single variable for all plugins).
  //    ["depends"][<full instance name>]:
  //        upward dependencies of the plugin.
  //        On instance initialization, step 1, all dependencies are empty.
  //        On instance initialization, step 2, all dependencies are initialized by their appropriate plugins to application-defined object, interface or other information.
  //    ["__interface"]:
  //        exists only on ["__f"] == 2: the application-defined object, returned via *pretval on instance initialization step 1.
  //
  //  OUPUT (*pretval)
  //
  //    See "DESCRIPTION" above.
  //
  //  EXPECTED RET. CODE:
  //    1 - success.
  //    -1 - compatibility error.
  //    -2 - unrecognized action code.
  //    <= -10 - application-defined error code.
  //
using namespace ns_plhost;
extern "C" __BMDX_DLLEXPORT bmdx::s_long bmdx_mod_request(bmdx::s_long sig, bmdx::s_long action, const bmdx::unity* ppara, bmdx::unity* pretval)
{
  bmdx::unity::rqcheck __rc(sig, action, ppara, pretval); if (__rc <= 0) { return __rc; }
  try {
    const int f = +*ppara / "__f" / -1;
    if (f == 1)
    {
      pretval->clear();
      pretval->objt<t_queue_supplier_impl>(0)();
      if (pretval->objItfsAttach<o_interfaces<t_queue_supplier_impl, ns_plhost::i_supplier> >() < 0) { return -12; }
      return 1;
    }
    else if (f == 2)
    {
      threadctl th;
      if (!th.start_auto<th_processor>(*ppara)) { return -12; }
      th.detach();
      return 1;
    }
    return -10; // wrong __f param.
  } catch (...) {}
  return -12;
}
