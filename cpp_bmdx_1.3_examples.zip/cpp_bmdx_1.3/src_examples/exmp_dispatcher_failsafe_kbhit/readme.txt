=========================================================================================
  Readme for
    exmp_dispatcher_failsafe_kbhit
=========================================================================================

  This project demonstrates message delivery by subscription.

  Several program instances are run in different terminal windows.
    They collect user input (characters), send it to an instance that works as server,
    and the server re-sends that data to all instances.
    Any instance displays only the data, received from the server,
    i.e. even in the original window, user input is not visible until it's echoed by server instance.

  The role of server is taken as the result of concurrency between all running instances.
    (Anyway, the server instance continues to be itself its own client.)
    The example is designed in such way that all clients regularly (once per second) refresh
    their subscription for server messages, and the concurrency for server role
    begins when re-subscription fails (e.g. if the server process has exited or has been terminated).

  The key point of this example is that, for the described behavior,
    the source code is very short (75 lines).

========================================================================================================================

  Build notes.

    1. Ensure BMDX library downloaded and unpacked so that src_code folder was placed
      aside (at the same level with) src_examples folder.
    2. Choose one of bld_* folders with build scripts, most closely matching with your target system.
    3. Correct bld_*/bld script so that compiler paths in the script were correct for your system.
    4. Note. Almost all scripts contain instructions for two compilers, one of which is likely
      the main system compiler.
      If both compilers are installed, any of them may be chosen to build the executable, via bld script arguments.
      E.g. "./bld 1" invokes compiler 1, "./bld 2" invokes compiler 2.
    5. Run the chosen script in its own directory (e.g. ./bld).
      If all goes well, it creates the executable in the same directory.

    (6). Alternatively, the project may be built with Qt/qmake.
      Use exmp_kbhit_win.pro or exmp_kbhit_nix.pro depending on the type of your system.
      Note that certain compiler paths in the project files may require correction to match with your system.
      The resulting executable is placed into out_bin folder at one level with src_examples folder.

========================================================================================================================

  Running the example.

    1. Open 2 or more terminal windows.
    2. Depending on the target system:
      ./kbhit
        or
      kbhit.exe
    3. Do some input into any of windows. All windows will display (echo) it.
    (4). When the server window is closed, one of the remaining windows becomes server approx. in one second.
      (If N>=3 processes were run, and one, which is server, has been closed,
      N-1 remaining processes notice that and concurrently try creating their own server object,
      and one of them succeeds.
      Others re-subscribe and start sending user input as soon as the server becomes available.)
