#include "../../src_code/bmdx_main.h"
#include <iostream>
#include <cstdio>

using namespace bmdx;
using namespace std;

unity cfg_server =
  "=|thread1|slots|qs_kbchar \n"
;

unity cfg_client =
  "=|thread1|slots|po_kbchar \n"
  "=|thread1|slots|qi_kbchar|input qsa; |LM|kbhit_server|thread1|qs_kbchar; \n"
;

struct t_th_server : threadctl::ctx_base
{
  void _thread_proc()
  {
    cref_t<dispatcher_mt> d;
    d.create2(0, "kbhit_server", cfg_server);
      if (!d->has_session()) { cerr << "\nNOTE kbhit server not started (an instance already exists?).\n"; return; }
    cout << "\nSUCC kbhit server started.\n";
    while (!b_stop()) { sleep_mcs(100); }
    cout << "\nNOTE kbhit server exiting.\n";
  }
};

int main(int, char**)
{
  console_io cons;

    // Attempt to start kbhit server in the current process. If fails: thread exits at once.
    //  Normally, the first kbhit process starts server successfully,
    //    others fail because of non-unique dispatcher process name.
    //    This is intended.
  threadctl server; server.start_auto<t_th_server>(0);

  dispatcher_mt client("kbhit_client" + unity(processctl::ff_mc().pid_self()).vcstr(), cfg_client);
    unity proxy; client.new_proxy(proxy, "thread1");
    o_iptr_t<i_dispatcher_mt> pdisp = proxy.pinterface<i_dispatcher_mt>(); if (!pdisp) { cerr << "ERR Failed to create the client dispatcher. Any key to exit.\n"; while (!cons.ugetch()) { sleep_mcs(100); } return 1; }
  cout << "SUCC kbhit client started: type a message in any kbhit window.\n";

  while (client.has_session())
  {
    unsigned int c = cons.ugetch();
      if (c == 0x1b) { break; }

    if (c != 0) { pdisp->msend("src=po_kbchar; trg=|LM|kbhit_server|thread1|qs_kbchar; text=" + unity(c).vcstr()); }

      // Optional behavior:
      //  1) Periodically re-subscribing, to catch server process normal exit or termination.
      //  2) If server (anywhere else) seems to be down, automatically starting it in the current process.
    if (1)
    {
      static cref_t<i_dispatcher_mt::tracking_info> tracking;
      static double t0 = clock_ms();
      if (clock_ms() - t0 > 1000)
      {
        tracking.cm_create0(0, 0, 0);
        pdisp->subscribe("|LM|kbhit_server|thread1|qs_kbchar", "qi_kbchar", 1, tracking);
        t0 = clock_ms();
      }
      if (!server && tracking && tracking->state < 0) { server.clear(); server.start_auto<t_th_server>(0); tracking.clear(); t0 = clock_ms(); }
    }

    unity m;
    if (pdisp->mget("qi_kbchar", m) > 0) { s_long c = m["text"].vint_l(); std::putchar(c == '\r' ? s_long('\n') : c); }

    sleep_mcs(100);
  }
  return 0;
}
