=========================================================================================
  Readme for
    exmp_dispatcher_fncall
=========================================================================================

  This simple project demonstrates function calls between threads in the same process,
    made with help of message dispatcher.

========================================================================================================================

  Build notes.

    1. Ensure BMDX library downloaded and unpacked so that src_code folder was placed
      aside (at the same level with) src_examples folder.
    2. Choose one of bld_* folders with build scripts, most closely matching with your target system.
    3. Correct bld_*/bld script so that compiler paths in the script were correct for your system.
    4. Note. Almost all scripts contain instructions for two compilers, one of which is likely
      the main system compiler.
      If both compilers are installed, any of them may be chosen to build the executable, via bld script arguments.
      E.g. "./bld 1" invokes compiler 1, "./bld 2" invokes compiler 2.
    5. Run the chosen script in its own directory (e.g. ./bld).
      If all goes well, it creates the executable in the same directory.

    (6). Alternatively, the project may be built with Qt/qmake.
      Use exmp_fncall_win.pro or exmp_fncall_nix.pro depending on the type of your system.
      Note that certain compiler paths in the project files may require correction to match with your system.
      The resulting executable is placed into out_bin folder at one level with src_examples folder.

========================================================================================================================

  Running the example.

    Depending on the target system:
      ./fncall
        or
      fncall.exe
    The main program thread starts the second thread, calls it twice, and displays the results.
