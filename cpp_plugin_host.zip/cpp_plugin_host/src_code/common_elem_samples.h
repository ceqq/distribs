#ifndef __common_elem_samples_H
#define __common_elem_samples_H

#include "common_elem.h"

namespace ns_plhost
{
  typedef _samples_block_t<float> t_block_samples;
}

namespace yk_c
{
  template<> struct bytes::type_index_t<ns_plhost::t_block_samples> : cmti_base_t<ns_plhost::t_block_samples, 2017, 8, 24, 11, -1> {};
  namespace { bytes::type_index_t<ns_plhost::t_block_samples> __cmti_inst_ns_plhost_t_block_samples; }
}


#endif
