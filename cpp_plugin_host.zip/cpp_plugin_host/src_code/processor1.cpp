#include "common_i_supplier_impl.h"
#include "common_elem_samples.h"
#include "common_elem_ampavg.h"

using namespace std;
using namespace bmdx;
using namespace bmdx_str::conv;

namespace ns_plhost
{

struct th_processor : threadctl::ctx_base
{
  void _thread_proc()
  {
    const unity& para = *pdata<unity>();

    // ========================================
    // Global plugins initialization phase.
    // ========================================

    if (para["__phase"].ref<s_long>() < 0) { return; }
    wstring name = +para / "__inst_name" / L""; if (name.empty()) { return; }

    double tavg = +para / "t_avg_ms" % 100 / 1000.; // dflt. 100 ms
      if (tavg < 1.e-6) { tavg = 1.e-6; } // 1 mcs
      if (tavg >= 86400) { tavg = 86400; } // 1 day
    s_long ichn = +para / "chn" % s_long(0);

      // During this instance initialization, the supplying instances are already created by plugin host,
      //  and capable to create valid data queue.
    const unity* pdep = para.path("depends");
    o_iptr_t<i_supplier> psup = pdep->hashi_c(1).pinterface<i_supplier>(); if (!psup) { return; }
    unity __q = psup->queue_alloc(name, paramline().list_h("chn", ichn));
    o_iptr_t<i_queue> pq = __q.pinterface<i_queue>(); if (!pq) { return; }

    while (para["__phase"].ref<s_long>() == 0) { if (b_stop()) { return; } sleep_mcs(10000); }

    // ========================================
    // Main loop of execution.
    // ========================================

    vec2_t<float> prv; // part of samples, left from the previous iteration

    s_ll iblk = -1; // abs. seq. number of the averaged block (< 0 - not initialized)
    double tblk00 = 0; // start time of the block iblk == 0 (seconds)
    double tprv2 = 0; // end time of prv (seconds)
    typedef hashx<unity, unity> H;

      // NOTE For example simplicity, any unsuccessful return from the main loop does not notify
      //  dependent plugins about exiting (this might be done by triggering some shared flag variable).
    while (para["__phase"].ref<s_long>() == 1)
    {
      if (b_stop()) { break; }

      // 1. Collect N samples (according to t_avg_ms)
      // 2. Calc avg. value.
      // 3. Set "the last block" flag if it's set in the input block.
      // 4. Push into all output queues.

      H qq;
      if (1)
      {
        svf_m_t<unity, th_processor>::L __lock;
        if (__lock.b_valid())
        {
          unity::o_api a(&svf_m_t<unity, th_processor>().rx()[name]); // it's expected that queues are initialized (before this thread has been created)
          H& qq0 = a.pu->ref<H>();

          unity::o_api::critsec_rc __lock(a.prc); if (__lock.state() < 1) { return; }
          qq.hashx_copy(qq0, false); // copy the current set of queues
        }
      }


      vec2_t<unity> bl;
      s_long res = pq->pop_n(pq->n(), bl);

        // NOTE For example simplicity, failures in queue push/pop operations are ignored.
        //    In the real DSP code, they would have been processed such that client plugin instances
        //    did not lose synchronization on getting the next successful portion of data after such a failure.
        //    This may be implemented differently, e.g. retrying to push data several times,
        //    pushing the special "data break" value etc.
      if (res == 1 && bl.n() > 0)
      {
        for (s_long ib = 0; ib < bl.n(); ++ib)
        {
          const t_block_samples& a = bl[ib].ref<t_block_samples>();
          bool b_last = !!(a.flags & 1);
          if (iblk < 0) { iblk = 0; tblk00 = a.t_s; tprv2 = tblk00; }

          unity __accu; __accu.objt<t_block_ampavg>(0)();
          t_block_ampavg& accu = __accu.ref<t_block_ampavg>(); // accumulates avg. values
            accu.ismp = iblk;
            accu.t_s = tblk00 + iblk * tavg;
            accu.smprate = 1 / tavg;

          while (true)
          {
            const double t1x = tblk00 + iblk * tavg;
            const double t2x = t1x + tavg; // the time point, where averaging should be made
            bool b_full = t2x <=  a.t2_s();

            s_ll i1 = (tprv2 - a.t_s) * a.smprate; if (i1 < 0) { i1 = 0; }
            s_ll i2 = (t2x - a.t_s) * a.smprate;

            if (b_full || b_last)
            {
              if (i2 >= a.samples.n()) { i2 = a.samples.n(); }

                // Average, clear prv, incr. block index.
              double sum = 0;
              for (s_long i = 0; i < prv.n(); ++i) { sum += std::fabs(prv[i]); }
              for (s_ll i = i1; i < i2; ++i) { sum += std::fabs(a.samples[s_long(i)]); }
              s_ll n2 = (i2 > i1 ? i2 - i1 : 0) + prv.n();
              if (n2 > 0) { sum /= n2; } else { sum = 0; }

              prv.clear();
              if (i2 > i1) { tprv2 = a.t2_s(i2); }
              ++iblk;

              if (b_last) { accu.flags |= 1; }
              accu.samples.push_back(sum);
            }
            else
            {
              i2 = a.samples.n();

                // Copy the samples into partially filled averaging block.
              if (i2 > i1) { _utils::copy(prv, a.samples.begin() + s_long(i1), a.samples.begin() + s_long(i2), 1); }
              tprv2 = a.t2_s();
            }
            if (i2 >= a.samples.n()) { break; }
          }


            // Push avg. into all consumer queues.
          if (accu.samples.n() || b_last)
          {
            for (s_long i = 0; i < qq.n(); ++i)
            {
              o_iptr_t<i_queue> pq = qq(i)->v[0].pinterface<i_queue>();
              if (pq) { pq->push_1(__accu); }
            }
          }


          if (b_last) { break; } // got the last block, exiting
        }
      }

      sleep_mcs(5000);
    }

    (s_long&)para["__ret_code"].ref<s_long>() = 1;
  }
};

}

using namespace ns_plhost;

  // ========================================
  // Plugin instance creation.
  // ========================================
  //
  //    May be called several times to create more than one instance, as configured by the user.
  //
  //  INPUT   (*ppara)
  //
  //  __f = 1
  //  __inst_name = <plugin instance name>. Instance name format: <plugin name><dot><instance name>
  //  __phase = 0 (initialization) | 1 (normal operation, will be set after all insts. of all plugins successfully initialized)
  //  __ret_code = ref. to s_long == 0. Plugin instance thread must set this to >= 1 on normal exit.
  //  depends = { plugin instance name, object + i_supplier attached }
  //  ... (merged cfg. parameters of the plugin and plugin instance)
  //
  //  OUTPUT   (*pretval)
  //
  //  [0] - threadctl object, with running thread attached. (The thread got a copy of *ppara.)
  //  [1] - all cases:
  //    a) empty
  //    b) private object with i_supplier attached - if this plugin generates and passes data sequences to dependend plugins.
  //    c) any other kind of data that will be passed to dependent plugins (via "depends" key), to establish inter-plugin links.
  //    The processor plugin uses case (b).
  //
  //  Returns:
  //    1 - success. -1 - compatibility error. -2 - unrecognized action code. >=0, -3..-9 - reserved.
  //    <= -10 - custom module-side error.
extern "C" __BMDX_DLLEXPORT bmdx::s_long bmdx_mod_request(bmdx::s_long sig, bmdx::s_long action, const bmdx::unity* ppara, bmdx::unity* pretval)
{
  if (!(action == 1 || action < 0)) { return -2; }
  if (action == 1 && !(sig == bmdx::unity::sig_struct() && ppara->compatibility() > 0 && pretval->compatibility() > 0)) { return -1; }
  try {
    if (+*ppara / "__f" % -1 != 1) { return -11; } // request type check
    wstring name = +*ppara / "__inst_name" / L""; if (name.empty()) { return -17; }

    const unity* pdep = ppara->path("depends");
    if (!(pdep && pdep->isHash() && pdep->hashS_c() && pdep->hashi_c(1).pinterface<i_supplier>())) { return -12; } // processor requires 1 input data queue

    pretval->clear();

    if (!pretval->ua(0).objt<threadctl>(1)()) { return -13; } // create thread control, associated with plugin instance
    (void)pretval->ua(1);

    if (1)
    {
      svf_m_t<unity, th_processor>::L __lock; if (!__lock.b_valid()) { return -18; }
      svf_m_t<unity, th_processor> queues;
      unity& z = queues.rxai0().hash(name); // rxai0 - ref. to static variable, with automatic initialization (0 args.)
        if (z.isObject()) { return -19; } // plugin instance (associated with name) may be initialized only once
      typedef hashx<unity, unity> H;
      if (!z.objt<H>(1)()) { return -15; } // creating static hash of data queues for the new plugin instance
      if (z.objItfsAttach<o_interfaces<H, i_supplier> >() < 1) {  z.clear(); return -16; } // attaching i_supplier
      (*pretval)[1] = z; // processor plugin is a supplier for other plugins
    }

    threadctl& th = (*pretval)[0].ref<threadctl>();
      if (!th.start_auto<th_processor>(*ppara)) { pretval->clear(); return -14; } // start thread

    return 1;
  } catch (...) { return -10; }
}
