#ifndef __common_i_supplier_impl_H
#define __common_i_supplier_impl_H

// NOTE A plugin may ignore this header and use any implementation for i_supplier and i_queue.
//  Plugin host does not access the implementation directly.
//  Consumer plugins may assume certain implementation and access it if agreed between consumer and supplier developers.

#include "common_i_supplier.h"
#include <deque>

namespace bmdx
{

  // i_supplier's object: { consumer instance name, (queue object + attached i_queue, arguments) }.
template<>
struct o_iimpl<hashx<unity, unity>, ns_plhost::i_supplier> : o_ibind<hashx<unity, unity>, ns_plhost::i_supplier>, ns_plhost::i_supplier
{
  virtual __t_i* __pMyI() { return this; }
  virtual void __itf_after_construct(s_long flags, o_itfset_base* src) {}
  virtual void __itf_before_destroy(s_long flags) {}

  typedef std::deque<unity> D;
  typedef hashx<unity, unity> H;

  virtual unity queue_alloc(const unity& name, const unity& args)
  {
      H* h = this->__pobj(0x21); if (!h) { return unity(); }
      unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return unity(); }
    try {
      unity k = name.vstr(); if (k.lenstr() < 1) { return unity(); }
      const H::entry* e = h->find(k);
        if (e) { return e->v[0]; }
      unity temp;
        if (!temp.ua(0).objt<D>(1, 2)()) { return unity(); }
        if (temp.ua(0).objItfsAttach<o_interfaces<D, ns_plhost::i_queue> >() < 0) { return unity(); }
        temp.ua(1) = args;
      unity& v = (*h)[k];
        v.swap(temp);
      return v[0];
    } catch (...) {}
    return unity();
  }

  virtual unity queue_args(const unity& name)
  {
      H* h = this->__pobj(0x21); if (!h) { return unity(); }
      unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return unity(); }
    try {
      unity k = name.vstr(); if (k.lenstr() < 1) { return unity(); }
      const H::entry* e = h->find(k);
        if (e) { return e->v[1]; }
    } catch (...) {}
    return unity();
  }

  virtual s_long queue_release(const unity& name)
  {
    H* h = this->__pobj(0x21); if (!h) { return -1; }
    unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return -1; }
    try {
      unity k = name.vstr();
      s_long res = h->remove(k);
      if (res < -1) { res = -1; }
      return res;
    } catch (...) {}
    return -1;
  }
};

template<>
struct o_iimpl<std::deque<unity>, ns_plhost::i_queue> : o_ibind<std::deque<unity>, ns_plhost::i_queue>, ns_plhost::i_queue
{
  virtual __t_i* __pMyI() { return this; }
  virtual void __itf_after_construct(s_long flags, o_itfset_base* src) {}
  virtual void __itf_before_destroy(s_long flags) {}

  typedef std::deque<unity> D;

  virtual s_ll n()
  {
    D* p = this->__pobj(0x21); if (!p) { return 0; }
    unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return 0; }
    return s_ll(p->size());
  }

  virtual s_long push_1(const unity& x)
  {
    D* p = this->__pobj(0x21); if (!p) { return -1; }
    unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return -1; }
    try { p->push_back(x); } catch (...) { return -1; }
    return 1;
  }

  virtual s_long pop_1(unity& dest)
  {
    D* p = this->__pobj(0x21); if (!p) { return -1; }
    unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return -1; }
    if (p->empty()) { return 0; }
    try { unity temp; temp.recreate_as(dest); temp = p->front(); p->pop_front(); dest.swap(temp); } catch (...) { return -1; }
    return 1;
  }

  virtual s_long pop_n(s_ll n, bmdx::vec2_t<unity>& dest)
  {
    D* p = this->__pobj(0x21); if (!p) { return -1; }
    unity::o_api::critsec_rc __lock(this->__p_itfs->__pidyn->prc); if (__lock.state() < 1) { return -1; }
    if (s_ll(p->size()) < n) { return 0; }
    for (s_ll i = 0; i <  n; ++i)
    {
      try { dest.push_back(p->front()); } catch (...) { return -2; }
      try { p->pop_front(); } catch (...) { dest.el_remove_last(); return -2; }
    }
    return 1;
  }

};

}

#endif
