#ifndef __common_elem_ampavg_H
#define __common_elem_ampavg_H

#include "common_elem.h"

namespace ns_plhost
{
  typedef _samples_block_t<double> t_block_ampavg;
}

namespace yk_c
{
  template<> struct bytes::type_index_t<ns_plhost::t_block_ampavg> : cmti_base_t<ns_plhost::t_block_ampavg, 2017, 8, 24, 12, -1> {};
  namespace { bytes::type_index_t<ns_plhost::t_block_ampavg> __cmti_inst_ns_plhost_t_block_ampavg; }
}


#endif
