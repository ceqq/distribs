#include "common_i_supplier.h"
#include "common_elem_ampavg.h"
#include <iostream>

using namespace std;
using namespace bmdx;
using namespace bmdx_str::conv;

namespace ns_plhost
{

struct th_indicator : threadctl::ctx_base
{
  void _thread_proc()
  {
    const unity& para = *pdata<unity>();

    // ========================================
    // Global plugins initialization phase.
    // ========================================

    if (para["__phase"].ref<s_long>() < 0) { return; }
    wstring name = +para / "__inst_name" / L""; if (name.empty()) { return; }
    string title = +para / "title" / "";

      // During this instance initialization, the supplying instances are already created by plugin host,
      //  and capable to create valid data queue.
    const unity* pdep = para.path("depends");
    o_iptr_t<i_supplier> psup = pdep->hashi_c(1).pinterface<i_supplier>(); if (!psup) { return; }
    unity __q = psup->queue_alloc(name);
    o_iptr_t<i_queue> pq = __q.pinterface<i_queue>(); if (!pq) { return; }

    while (para["__phase"].ref<s_long>() == 0) { if (b_stop()) { return; } sleep_mcs(10000); }

    // ========================================
    // Main loop of execution.
    // ========================================

    double t0 = clock_ms();
    while (para["__phase"].ref<s_long>() == 1)
    {
      if (b_stop()) { break; }

      vec2_t<unity> bl;
      s_long res = pq->pop_n(pq->n(), bl);
      if (res == 1 && bl.n() > 0)
      {
        s_long i0 = bl.n() - 3; if (i0 < 0) { i0 = 0; }
        string s_accu;
        bool b_last = false;
        for (s_long j = 0; j < bl.n(); ++j)
        {
          const t_block_ampavg& a = bl[j].ref<t_block_ampavg>();
          b_last = b_last || !!(a.flags & 1);

          for (s_long j2 = 0; j2 < a.samples.n(); ++j2)
          {
            double f = std::fabs(a.samples[j2]);
            if (f <= 1.e-6) { f = 0; } else if (f < 0.01) { f = 0.01; } else if (f > 1) { f = 1; }
            string s = title;
            s += string(f * 56, '=');
            s += ' ';
            s += ftocs(f, 3);
            s += ' ';
            s += ftocs(a.t2_s(j2), 6, 1);
            s += " s\n";
            s_accu += s;
          }
        }
        cerr << s_accu;
        if (b_last) { break; }
      }
      else if (res == -1)
      {
        string s = "(error) ";
        s += ftocs((clock_ms() - t0) / 1000, 6, 1);
        s += "\n";

        cerr << s;
      }

      sleep_mcs(10000);
    }

    (s_long&)para["__ret_code"].ref<s_long>() = 1;
  }
};

}

using namespace ns_plhost;

  // ========================================
  // Plugin instance creation.
  // ========================================
  //
  //    May be called several times to create more than one instance, as configured by the user.
  //
  //  INPUT   (*ppara)
  //
  //  __f = 1
  //  __inst_name = <plugin instance name>. Instance name format: <plugin name><dot><instance name>
  //  __phase = 0 (initialization) | 1 (normal operation, will be set after all insts. of all plugins successfully initialized)
  //  __ret_code = ref. to s_long == 0. Plugin instance thread must set this to >= 1 on normal exit.
  //  depends = { plugin instance name, object + i_supplier attached }
  //  ... (merged cfg. parameters of the plugin and plugin instance)
  //
  //  OUTPUT   (*pretval)
  //
  //  [0] - threadctl object, with running thread attached. (The thread got a copy of *ppara.)
  //  [1] - all cases:
  //    a) empty
  //    b) private object with i_supplier attached - if this plugin generates and passes data sequences to dependend plugins.
  //    c) any other kind of data that will be passed to dependent plugins (via "depends" key), to establish inter-plugin links.
  //    The indicator plugin uses case (a).
  //
  //  Returns:
  //    1 - success. -1 - compatibility error. -2 - unrecognized action code. >=0, -3..-9 - reserved.
  //    <= -10 - custom module-side error.
  //
extern "C" __BMDX_DLLEXPORT bmdx::s_long bmdx_mod_request(bmdx::s_long sig, bmdx::s_long action, const bmdx::unity* ppara, bmdx::unity* pretval)
{
  if (!(action == 1 || action < 0)) { return -2; }
  if (action == 1 && !(sig == bmdx::unity::sig_struct() && ppara->compatibility() > 0 && pretval->compatibility() > 0)) { return -1; }
  try {
    if (+*ppara / "__f" % -1 != 1) { return -11; } // request type check
    wstring name = +*ppara / "__inst_name" / L""; if (name.empty()) { return -17; }

    const unity* pdep = ppara->path("depends");
    if (!(pdep && pdep->isHash() && pdep->hashS_c() && pdep->hashi_c(1).pinterface<i_supplier>())) { return -12; } // indicator requires 1 input data queue

    pretval->clear();

    if (!pretval->ua(0).objt<threadctl>(1)()) { return -13; } // create thread control, associated with plugin instance
    (void)pretval->ua(1); // this will remain empty (indicator plugin is not a supplier for others)

    threadctl& th = (*pretval)[0].ref<threadctl>();
      if (!th.start_auto<th_indicator>(*ppara)) { pretval->clear(); return -14; } // start thread

    return 1;
  } catch (...) { return -10; }
}
