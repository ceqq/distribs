================================================================

This project shows how to create generic host application,
which is able to load and execute multiple plugins,
created with different compilers on the same platform.

The host application does not distinguish the kind of plugins it's loading.

================================================================

Binary files.

In the scope of example project, 3 kinds of plugins are defined,
working according to the following scheme:

Data source --> data processor --> data endpoint (final consumer).

The data is 1 channel of audio samples, which are averaged,
and volume level is calculated and displayed.

Roles of the binary modules, compiled from project files:

plhost (executable):
  load configuration, load plugins, start threads, watch termination conditions,
  ensure threads completion, exit.

supplier1 (shared library):
  load wav, push audio samples into the input data queue.

processor1 (shared library):
  pop samples, calc. avg. amplitude for a time window,
  push amplitude into the output data queue.

indicator1 (shared library):
  pop volume (avg. amplitude) values,
  display time and volume in terminal window.

================================================================

Build.

NOTE 1

Before building binaries of this project,
please ensure you downloaded BMDX library:

hashx.dp.ua/cpp_bmdx_1.1.zip

Unpack the archive into ./src_code folder.
Final paths should look like:

./src_code/cpp_bmdx_1.1/src_code/bmdx_main.h

NOTE 2

To basically work, any of build scripts (bldwin.cmd, bldlin etc.)
calls same one compiler to create 4 binaries.

Windows: by default, 32-bit MinGW is expected in c:\mingw\bin.
POSIX: main system compiler is called w/o path.

The scripts also contain additional commented lines,
that may be quickly uncommented to use alternate compiler
for selected binaries.
This is a quick "heterogeneous" test for the host.

================================================================

Architectural note.

The number and parameters of plugins are specified in plhost.cfg.
Each plugin binary, once loaded, may be used to create multiple plugin instances.
The host assumes that each plugin instance is a thread + additional objects.

The example connects data supplier to consumers (1:many) to pass them data.
A consumer plugin instance asks for data queue creation
from the supplier plugin instance, to which the consumer is bound by configuration.
Values in the queue are held in blocks, by reference (ref.-counted).
Blocks are shared between consumers, to efficiently address large amount of data.

(This particular data queues architecture concerns only with plugins in the example.
Any other plugins are not required to use or depend on it.)

The host asks all live threads to exit in any of the following cases:
a) All plugin instances (threads), configured as data endpoint, had exited.
b) All plugin instances have exited.
c) Any of the plugin instances exited due to error (had not set normal exit code).
d) The user presses Esc.
  (Reading keyboard input by the host is implemented as example only.
  In real application, the input would be handled by separate kind of plugin.)

================================================================

