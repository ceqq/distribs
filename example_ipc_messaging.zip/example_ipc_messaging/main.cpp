#define bmdx_part_shm 1
#include "bmdx_cpiomt.h"
using namespace bmdx_shm;

#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv)
{
    // Figure out if the program runs as server or client, to know which buffer to create (for request or for response).
  const bool b_server = (string(argv[0]).find("server") != string::npos) || (argc >= 2 && string(argv[1]) == "s");

  shmfifo_s req("BMDXMsgQueueDir21");
  shmfifo_s resp("BMDXMsgQueueDir12");

  bmdx::console_io cons;

  string s;

  if (b_server)
  {
    cout << "SERVER: waiting for message (ESC to exit)..." << endl;

    while (cons.ugetch() != 0x1b) // ESC
    {
      try { s = req.pop_str(100); } catch (...) { continue; }
      if (req.res < 0) { cout << "SERVER: pop_str: " << req.res << " (failure)" << endl; }

      if (req.res > 0)
      {
        cout << "SERVER: got message: [" << s << "]" << endl;
        cout << "SERVER: responding (echo)..." << endl;
        resp.push_message(s); // non-blocking, should succeed because the client is most probably alive
        if (resp.res != 0) { cout << "SERVER: push_message: " << resp.res << (resp.res > 0 ? " (success)" : " (failure)") << endl; }
      }
    }
  }
  else
  {
    cout << "CLIENT: sending message..." << endl;

    resp.get_message(0, false); // ensure input queue creation at once, because that server responds very quickly
    req.push_message(string() + "Hello! Message from client " + argv[0], -1);
    cout << "CLIENT: push_message: " << req.res << (req.res > 0 ? " (success)" : " (failure)") << endl;
    if (req.res > 0)
    {
      s = resp.pop_str(-1);
      if (resp.res > 0) { cout << "CLIENT: got response: [" << s << "]" << endl; }
      if (resp.res <= 0) { cout << "CLIENT: pop_str: " << resp.res << " (failure)" << endl; }
    }

    cout << endl << endl << "TYPE MESSAGE YOURSELF. ESC to exit program." << endl;
    while (true)
    {
      s.clear();
      bool b_esc = false;
      while (true)
      {
        char c = cons.ugetch();
        if (c == 0x1b) { b_esc = true; break; }
        if (c == 0) { bmdx::sleep_mcs(10000); continue; }

        if (c == 0xd || c == 0xa) { cout << endl; break; }
        s += c;
        cout << c;
      }
      if (b_esc) { break; }

      double t0 = bmdx::clock_ms();
      req.push_message(s, -1);
      cout << "CLIENT: push_message: " << req.res << (req.res > 0 ? " (success)" : " (failure)") << endl;
      if (req.res > 0)
      {
        s = resp.pop_str(-1);
        double t1 = bmdx::clock_ms();
        if (resp.res > 0) { cout << "CLIENT: got response: [" << s << "]" << endl << "  roundtrip time, ms: " << (t1 - t0) << endl; }
        if (resp.res <= 0) { cout << "CLIENT: pop_str: " << resp.res << " (failure)" << endl; }
      }
    }

  }

  return 0;
}
