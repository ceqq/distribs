================================================================

This project demonstrates passing text messages between programs
via shared memory.

================================================================

Build.

1. Put bmdx_cpiomt.h into the current directory.
2. Run build script, corresponding to the current platform,
  or compile main.cpp manually as necessary.

Most of the scripts support 2 compilers, allowing to choose
different compiler for client and server program. For example,
  bldwin 1 2
builds server program with MinGW, client program with MSVC.

================================================================

Run.

The build script creates two programs
(ipmsg, ipmsg_server). In the form of source code, they are identical.

The program having "server" in its title (or run with "a" as its first argument),
receives text messages and responds (echo).

The other program works as "client", waiting for user input,
sending it to server, and getting response.

In the example, two queues with hard-coded names are used for that.

================================================================
