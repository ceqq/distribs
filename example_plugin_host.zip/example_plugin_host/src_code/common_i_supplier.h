#ifndef __common_i_supplier_H
#define __common_i_supplier_H

#include "cpp_bmdx_1.1/src_code/bmdx_main.h"

namespace ns_plhost
{

using bmdx::unity;
using bmdx::s_long;
using bmdx::s_ll;

  // Access to supplier's data queues.
struct i_supplier
{
    // name - data consumer plugin instance name (non-empty string) or its derivative.
    //   Only 1 queue per name may be created.
    // args - optional arguments, copied and kept together with the queue object.
    // Returns:
    //   a) on success: queue object with i_queue attached.
    //     The queue has been created or already exists.
    //     For example: see common_elem_samples.h, common_elem_ampavg.h.
    //   b) on failure: empty.
  virtual unity queue_alloc(const unity& name, const unity& args = unity()) = 0;

    // name - data consumer plugin instance name (non-empty string) or its derivative.
    // Returns:
    //   a) copy of arguments, passed when the queue with the name has been allocated.
    //   b) on failure: empty.
  virtual unity queue_args(const unity& name) = 0;

    // name - data consumer plugin instance name or its derivative.
    // Returns:
    //   1 - released.
    //   0 - the queue with this name does not exist.
    //   -1 - failure.
  virtual s_long queue_release(const unity& name) = 0;
};



  // Basic queue interface.
  // NOTE Queue element type is bmdx::unity. It may contain direct value,
  //    or reference task-specific object (as agreed between supplier and consumer).
struct i_queue
{
    // Returns queue size.
  virtual s_ll n() = 0;

    // Returns:
    //   1 - pushed.
    //   -1 - failure.
  virtual s_long push_1(const unity& x) = 0;

    // Returns:
    //   1 - popped.
    //   0 - the queue is empty.
    //   -1 - failure.
  virtual s_long pop_1(unity& dest) = 0;

    // dest is appended with n elements, popped from the queue.
    //  (dest is not cleared before appending, base index is not changed.)
    // Returns:
    //   1 - popped n elements.
    //   0 - queue size < n. dest == const.
    //   -1 - failure. dest == const.
    //   -2 - failure. May have popped < n elements (dest may be modified).
    //    NOTE Depending on implementation, ret. code -2 may be unused.
  virtual s_long pop_n(s_ll n, bmdx::vec2_t<unity>& dest) = 0;
};


}

  // Proxy classes to support cross-module o_iptr_t for i_supplier, i_queue.
namespace bmdx
{
  template<> struct o_proxy<ns_plhost::i_supplier> : o_proxy_base<ns_plhost::i_supplier>
  {
    static inline const char* __iname() { return "bmdx-dev/bmdx_example_plhost/i_supplier/1.0"; }

    struct __queue_alloc { typedef unity (*PF)(__Interface*, const unity*, const unity*); static unity F(__Interface* __pi, const unity* name, const unity* args) { return __pi->queue_alloc(*name, *args); } };
      virtual unity queue_alloc(const unity& name, const unity& args) { return __call<__queue_alloc>()(__psi(), &name, &args); }
    struct __queue_args { typedef unity (*PF)(__Interface*, const unity*); static unity F(__Interface* __pi, const unity* name) { return __pi->queue_args(*name); } };
      virtual unity queue_args(const unity& name) { return __call<__queue_args>()(__psi(), &name); }
    struct __queue_release { typedef s_long (*PF)(__Interface*, const unity*); static s_long F(__Interface* __pi, const unity* name) { return __pi->queue_release(*name); } };
      virtual s_long queue_release(const unity& name) { return __call<__queue_release>()(__psi(), &name); }

    typedef unity_common::fn_list<__queue_alloc, __queue_args, __queue_release> __Methods;

  };
  namespace { o_proxy<ns_plhost::i_supplier> __o_proxy_ns_plhost_i_supplier_inst; }

  template<> struct o_proxy<ns_plhost::i_queue> : o_proxy_base<ns_plhost::i_queue>
  {
    static inline const char* __iname() { return "bmdx-dev/bmdx_example_plhost/i_queue/1.0"; }

    struct __n { typedef s_ll (*PF)(__Interface*); static s_ll F(__Interface* __pi) { return __pi->n(); } };
      virtual s_ll n() { return __call<__n>()(__psi()); }
    struct __push_1 { typedef s_long (*PF)(__Interface*, const unity*); static s_long F(__Interface* __pi, const unity* x) { return __pi->push_1(*x); } };
      virtual s_long push_1(const unity& x) { return __call<__push_1>()(__psi(), &x); }
    struct __pop_1 { typedef s_long (*PF)(__Interface*, unity*); static s_long F(__Interface* __pi, unity* dest) { return __pi->pop_1(*dest); } };
      virtual s_long pop_1(unity& dest) { return __call<__pop_1>()(__psi(), &dest); }
    struct __pop_n { typedef s_long (*PF)(__Interface*, s_ll, bmdx::vec2_t<unity>*); static s_long F(__Interface* __pi, s_ll n, bmdx::vec2_t<unity>* dest) { return __pi->pop_n(n, *dest); } };
      virtual s_long pop_n(s_ll n, bmdx::vec2_t<unity>& dest) { return __call<__pop_n>()(__psi(), n, &dest); }

    typedef unity_common::fn_list<__n, __push_1, __pop_1, __pop_n> __Methods;

  };
  namespace { o_proxy<ns_plhost::i_queue> __o_proxy_ns_plhost_i_queue_inst; }
}

#endif
