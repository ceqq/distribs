#include "common_i_supplier_impl.h"
#include "common_elem_samples.h"
#include "wav_reader_v1.h"

using namespace std;
using namespace bmdx;
using namespace bmdx_str::conv;
using namespace utils_audio;
using namespace utils_audio::wav_reader_v1;

namespace ns_plhost
{

struct th_supplier : threadctl::ctx_base
{
  void _thread_proc()
  {
    const unity& para = *pdata<unity>();

    // ========================================
    // Global plugins initialization phase.
    // ========================================

    if (para["__phase"].ref<s_long>() < 0) { return; }
    wstring name = +para / "__inst_name" / L""; if (name.empty()) { return; }

    double spr = +para / "speed_ratio" % 1.; // dflt. 1x
      if (spr < 0.001) { spr = 0.001; }
      if (spr >= 10000) { spr = 10000; }
    unity datasrc = +para / "datasrc" / unity();
      if (!(datasrc.isArray() || datasrc.isEmpty())) { datasrc = unity().array(datasrc); }

    //  no dependencies
    // const unity* pdep = para.path("depends");

    while (para["__phase"].ref<s_long>() == 0) { if (b_stop()) { return; } sleep_mcs(10000); }

    // ========================================
    // Main loop of execution.
    // ========================================

    // 1. Open wav file.
    // 2 Loop:
    //    2.1 Prepare sample frames block container.
    //    2.2 Load N frames (according to sample rate, speed_ratio, and certain chosen latency), put into container.
    //    2.3 Set "the last block" flag if wav file end reached.
    //    2.4 Push samples into all output queues.

    double smprate;
    wav_reader rd;
    s_ll N = 0;

    if (datasrc.isEmpty())
    {
      smprate = 44100;
      N = 60 * smprate;
    }
    else
    {
      for (s_long i = datasrc.arrlb(); i <= datasrc.arrub(); ++i) { string fn = datasrc.vcstr(i); if (file_utils().is_valid_path(fn)) { rd.fs_open(fn.c_str()); if (rd.fs_is_open()) { break; } } }
      if (!rd.fs_is_open()) { return; }
      smprate = rd.rate();
      N = rd.nfr();
    }

    s_ll M = spr * smprate * 0.1; // latency 0.1 s
      if (M < 1) { M = 1; }

    s_ll ismp = 0; // abs. seq. sample number (it's assumed that sample rate never changes)
    double tsend0 = clock_ms() / 1000;
    typedef hashx<unity, unity> H;

       // NOTE For example simplicity, any unsuccessful return from the main loop does not notify
      //  dependent plugins about exiting (this might be done by triggering some shared flag variable).
   while (true)
    {
      if (b_stop()) { break; }

      bool b_last =
        (para["__phase"].ref<s_long>() != 1)
        || ismp + M >= N;

      H qq;
      if (1)
      {
        svf_m_t<unity, th_supplier>::L __lock;
        if (__lock.b_valid())
        {
          unity::o_api a(&svf_m_t<unity, th_supplier>().rx()[name]); // it's expected that queues are initialized (before this thread has been created)
          H& qq0 = a.pu->ref<H>();

          unity::o_api::critsec_rc __lock(a.prc); if (__lock.state() < 1) { return; }
          qq.hashx_copy(qq0, false); // copy the current set of queues
        }
      }
      unity h_accu; h_accu.u_clear(utHash);
      for (s_long i = 0; i < qq.n(); ++i)
      {
        unity& z = h_accu.hash(+qq(i)->v[1] / "chn" % s_long(0));
        if (!z.isObject())
        {
          z.objt<t_block_samples>(0)();
          t_block_samples& accu = z.ref<t_block_samples>(); // accumulates avg. values
            accu.ismp = ismp;
            accu.t_s = 0 + ismp / smprate;
            accu.smprate = smprate;
            if (b_last) { accu.flags |= 1; }
        }
      }


        // NOTE For example simplicity, failures in queue push/pop operations are ignored.
        //    In the real DSP code, they would have been processed such that client plugin instances
        //    did not lose synchronization on getting the next successful portion of data after such a failure.
        //    This may be implemented differently, e.g. retrying to push data several times,
        //    pushing the special "data break" value etc.

      s_ll M2 = M; if (b_last) { M2 = N - ismp; if (M2 > M) { M2 = M; } }

      basic_string<sample32f> smpbuf;
      if (!datasrc.isEmpty())
      {
        smpbuf.resize(M2 * rd.nch(), 0.F);
        if (rd.fs_read_32f(M2, &smpbuf[0]) != M2) { return; }
      }
      for (s_long j = 1; j <= h_accu.hashS_c(); ++j)
      {
        s_long ichn = h_accu.hashi_key_c(j).vint_l();
        unity& z = h_accu.hashi(j);
        t_block_samples& accu = z.ref<t_block_samples>();
        if (datasrc.isEmpty())
        {
          for (s_ll i = 0; i < M2; ++i) { accu.samples.el_append(float(std::sin(0.1 * (ismp + i) / smprate * 2 * 3.1415926))); }
        }
        else
        {
          if (ichn >= 0 && ichn < rd.nch()) { for (s_ll i = 0; i < M2; ++i) { accu.samples.el_append(float(smpbuf[i * rd.nch() + ichn])); } }
            else { accu.samples.el_append_m(M2, 0.F); }
        }
      }
      ismp += M2;

        // Push data into all consumer queues.
      if (M2 || b_last)
      {
        for (s_long i = 0; i < qq.n(); ++i)
        {
          o_iptr_t<i_queue> pq = qq(i)->v[0].pinterface<i_queue>();
          unity& z = h_accu.hash(+qq(i)->v[1] / "chn" % s_long(0));
          if (pq) { pq->push_1(z); }
        }
      }

      if (b_last) { break; } // got the last block, exiting

      if (1)
      {
        double tfact = clock_ms() / 1000 - tsend0;
        double tsync = double(ismp) / smprate / spr;
        s_ll tslp = s_ll((tsync - tfact) * 1e6);
        if (tslp < 100) { tslp = 100; }
        sleep_mcs(tslp);
      }
    }

    (s_long&)para["__ret_code"].ref<s_long>() = 1;
  }
};

}

using namespace ns_plhost;

  // ========================================
  // Plugin instance creation.
  // ========================================
  //
  //    May be called several times to create more than one instance, as configured by the user.
  //
  //  INPUT   (*ppara)
  //
  //  __f = 1
  //  __inst_name = <plugin instance name>. Instance name format: <plugin name><dot><instance name>
  //  __phase = 0 (initialization) | 1 (normal operation, will be set after all insts. of all plugins successfully initialized)
  //  __ret_code = ref. to s_long == 0. Plugin instance thread must set this to >= 1 on normal exit.
  //  ... (merged cfg. parameters of the plugin and plugin instance)
  //
  //  OUTPUT   (*pretval)
  //
  //  [0] - threadctl object, with running thread attached. (The thread got a copy of *ppara.)
  //  [1] - all cases:
  //    a) empty
  //    b) private object with i_supplier attached - if this plugin generates and passes data sequences to dependend plugins.
  //    c) any other kind of data that will be passed to dependent plugins (via "depends" key), to establish inter-plugin links.
  //    The supplier plugin uses case (b).
  //
  //  Returns:
  //    1 - success. -1 - compatibility error. -2 - unrecognized action code. >=0, -3..-9 - reserved.
  //    <= -10 - custom module-side error.
extern "C" __BMDX_DLLEXPORT bmdx::s_long bmdx_mod_request(bmdx::s_long sig, bmdx::s_long action, const bmdx::unity* ppara, bmdx::unity* pretval)
{
  bmdx::unity::rqcheck __rc(sig, action, ppara, pretval); if (__rc <= 0) { return __rc; } 
  try {
    if (+*ppara / "__f" % -1 != 1) { return -11; } // request type check
    wstring name = +*ppara / "__inst_name" / L""; if (name.empty()) { return -17; }

    // no dependencies
    // const unity* pdep = ppara->path("depends");

    pretval->clear();

    if (!pretval->ua(0).objt<threadctl>(1)()) { return -13; } // create thread control, associated with plugin instance
    (void)pretval->ua(1);

    if (1)
    {
      svf_m_t<unity, th_supplier>::L __lock; if (!__lock.b_valid()) { return -18; }
      svf_m_t<unity, th_supplier> queues;
      unity& z = queues.rxai0().hash(name); // rxai0 - ref. to static variable, with automatic initialization (0 args.)
        if (z.isObject()) { return -19; } // plugin instance (associated with name) may be initialized only once
      typedef hashx<unity, unity> H;
      if (!z.objt<H>(1)()) { return -15; } // creating static hash of data queues for the new plugin instance
      if (z.objItfsAttach<o_interfaces<H, i_supplier> >() < 1) {  z.clear(); return -16; } // attaching i_supplier
      (*pretval)[1] = z; // processor plugin is a supplier for other plugins
    }

    threadctl& th = (*pretval)[0].ref<threadctl>();
      if (!th.start_auto<th_supplier>(*ppara)) { pretval->clear(); return -14; } // start thread

    return 1;
  } catch (...) { return -10; }
}
