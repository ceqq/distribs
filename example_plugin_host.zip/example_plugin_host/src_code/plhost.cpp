#include "cpp_bmdx_1.1/src_code/bmdx_main.h"
#include <iostream>

using namespace std;
using namespace bmdx;

struct plugin_ctx
{
  threadctl th;
  unity::mod_handle mh; // NOTE when clearing or overwriting mh, ensure th, supplier, cfg_inst, cfg_pl, ret_code to be cleared or recreated to belong to the current module
  unity supplier; // access to i_supplier
  bool is_endpoint;
  unity cfg_inst;
  unity cfg_pl;
  unity ret_code; // the plugin instance sets to >=1 when exits normally; optionally may set to < 0 when exits with error

  plugin_ctx() : is_endpoint(false) {}
  ~plugin_ctx() { clear(); }

  void clear() { th.clear(); supplier.recreate(); cfg_inst.recreate(); cfg_pl.recreate(); ret_code.recreate(); mh.clear(); is_endpoint = false; }
};

int main(int argc, char** argv)
{
  // 1. Load configuration.
  unity cfg;
  hashx<wstring, plugin_ctx> pls;

  try {
    string fnp_cfg = argc >= 2 ? argv[1] : "plhost.cfg";
    unity s = file_utils().load_string("text local8bit utf16le utf16be", fnp_cfg); if (s.isEmpty()) { return 0; }
    cfg = paramline().decode_tree(s.vstr());
  } catch (...) { return 1; }

  // 2. Eval. plugin dependencies, check for absence of loops.
  try {
    const unity* p = cfg.path("plugins"); if (!(p && p->isHash() && p->hashS_c())) { return 0; }
    hashx<wstring, hashx<wstring, int> > hdep;
    hashx<wstring, unity> hcfg_inst;
    hashx<wstring, unity> hcfg_pl;
    for (s_long i = 1; i <= p->hashS_c(); ++i)
    {
      const unity* p2 = p->hashi_c(i).path("instances");
      if (p2 && p2->isHash()) { for (s_long j = 1; j <= p2->hashS_c(); ++j) {
        wstring k_inst = p->hashi_key_c(i).vstr() + L"." + p2->hashi_key_c(j).vstr();

        (void)hdep[k_inst];
        hcfg_inst[k_inst] = p2->hashi_c(j);
        hcfg_pl[k_inst] = +cfg / (L"plugins|" + p->hashi_key_c(i).vstr()) / unity();

        const unity* pdep = p2->hashi_c(j).path("depends");
        if (pdep && pdep->isArray()) { for (s_long j2 = 1; j2 <= pdep->arrub(); ++ j2) { (void)hdep[k_inst][(*pdep)[j2].vstr()]; } }
      } }
    }
    while (hdep.n())
    {
      bool b_loop = true;
      wstring k;
      for (s_long i = 0; i < hdep.n(); ++i)
      {
        k = hdep(i)->k;
        if (hdep(i)->v.n() == 0)
        {
          b_loop = false;
          for (s_long j = 0; j < hdep.n(); ++j)  { hdep(j)->v.remove(k); }
          hdep.remove_i(i);
          break;
        }
      }
      if (b_loop) { return 3; }
      pls[k].cfg_inst = hcfg_inst[k];
      pls[k].cfg_pl = hcfg_pl[k];
      pls[k].is_endpoint = +pls[k].cfg_inst / "endpoint" % false;
      pls[k].ret_code.objt<s_long>(0)(0);
    }
  } catch (...) { return 2; }

  // 3. Load plugin modules.
  s_long ind1 = -1;
  for (s_long i = 0; i < pls.n(); ++i)
  {
    plugin_ctx& c = pls(i)->v;
    try {
      unity bin = +c.cfg_pl / "bin" / unity(); if (!bin.isArray()) { ind1 = i; break; }
      for (s_long j = 1; j <= bin.arrub(); ++j)
      {
        string path = bin[j].vcstr();
        if (file_utils().is_valid_path(path)) { c.mh = unity::mod(path.c_str(), true); }
        if (c.mh) { break; }
      }
      if (!c.mh) { ind1 = i; break; }
    } catch (...) { ind1 = i; break; }
  }
  if (ind1 >= 0) { return 100 * ind1 + 4; }


  static s_long phase = 0;


  struct term_ths
  {
    void f(hashx<wstring, plugin_ctx>& pls, s_long timeout_ms)
    {
      double t0 = clock_ms();
      for (s_long i = 0; i < pls.n(); ++i) { pls(i)->v.th.signal_stop(); }
      bool b = false;
      for (s_long i = 0; i < pls.n(); ++i) { b = clock_ms() - t0 >= timeout_ms; if (b) { break; } if (pls(i)->v.th) { i = -1; sleep_mcs(1000); continue; } }
      if (b) { for (s_long i = 0; i < pls.n(); ++i) { pls(i)->v.th.terminate(); } }
      if (b) { sleep_mcs(1000000); }
      for (s_long i = pls.n() - 1; i >= 0; --i) { pls(i)->v.clear(); }
    }
  };


  // 4. Initialize each plugin instance.
  ind1 = -1;
  for (s_long i = 0; i < pls.n(); ++i)
  {
    plugin_ctx& c = pls(i)->v;
    try {
      unity para, inst;

        // Input parameters for plugin instance initialization.
      para.hash("__f") = 1;
      para.hash("__inst_name") = pls(i)->k;
      para.hash("__phase").set_obj(phase, false);
      para.hash("__ret_code") = c.ret_code;
      paramline().merge(para, c.cfg_pl);
      paramline().merge(para, c.cfg_inst);

      const unity* pdep = c.cfg_inst.path("depends");
      if (pdep && pdep->isArray())
      {
        unity hdep; hdep.hash_clear(1);
        for (s_long i = 1; i <= pdep->arrub(); ++i) { wstring k = pdep->vstr(i); hdep.hash_set(k, unity()); if (pls.find(k)) { hdep.hash_set(k, pls[k].supplier); } }
        para.hash("depends") = hdep;
      }

      s_long res_rq = c.mh.request(para, inst);
      if (res_rq != 1)
      {
        cerr << "ERR c.mh.request: " << res_rq << "; plugin: " << wsToBs(pls(i)->k) << endl;
        ind1 = i; 
        break;
      }

        // Objects, returned by the plugin on successfull instance creation:
        //    [0] threadctl object, representing the plugin instance.
        //        The thread should be running and waiting for para["__phase"].ref<s_long>() to become 1.
        //    [1] By default, private object + attached i_supplier, both associated 1:1 with plugin instance.
        //        (Factual value may be different, depending on the plugin and its dependent plugins architecture.)
      c.th.swap(inst[0].ref<threadctl>());
      c.supplier.swap(inst[1]);
      if (!c.th) { ind1 = i; break; }
    } catch (...) { ind1 = i; break; }
  }
  if (ind1 >= 0) { term_ths().f(pls, 1000); return 100 * ind1 + 5; }

  // 5. Set start flag.
  phase = 1;

  // 6. Wait for termination condition (Esc or all endpoints exited or all threads exited or any thread exited due to error).
  // NOTE This block does not throw exceptions.
  ind1 = -1;
  if (1)
  {
    console_io cons;
    while (1)
    {
      int flags = 0;
      for (s_long i = 0; i < pls.n(); ++i)
      {
        plugin_ctx& c = pls(i)->v;
        if (c.is_endpoint) { flags |= 1; }
        if (c.th) { flags |= c.is_endpoint ? 2 : 4; }
        if (!c.th && c.ret_code.ref<s_long>() <= 0) { ind1 = i; flags |= 8; }
      }
      if (!!(flags & 8)) { break; }
      if ((flags & 6) == 0) { break; }
      if ((flags & 3) == 1) { break; }
      if (cons.ugetch() == 0x1b) { break; }
      sleep_mcs(10000);
    }
  }

  // 7. Stop all remaining threads. Unload plugins in reverse order.
  term_ths().f(pls, 1000);

  return ind1 >= 0 ? 100 * ind1 + 6 : 0;
}
