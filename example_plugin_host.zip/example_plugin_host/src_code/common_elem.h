#ifndef __common_elem_H
#define __common_elem_H

#include "common_i_supplier.h"

namespace ns_plhost
{

  // Queue element (in the scope of plugin host example project).
  //  NOTE The structure is designed as cross-module.
  //  (It consists of several 8-byte fields + 1 cross-module object.
  //  Each of them is treated equally by any compiler.)
template<class T>
struct _samples_block_t
{
  s_ll ismp; // global index of the first sample in block
  double t_s; // absolute time (s) of the first sample, measured from start of sequence
  double smprate; // for this block only: number of samples per second
  s_ll flags; // 0x1: this block is the last in sequence, no more will be pushed (this is only for signaling about normal sequence end, not for error notifications)
  bmdx::vec2_t<T> samples;

  _samples_block_t() : ismp(0), t_s(0), smprate(0), flags(0) {}

  double t2_s() const { return t_s + (smprate ? samples.n() / smprate : 0); }
  double dt_s() const { return (smprate ? samples.n() / smprate : 0); }
  double t2_s(s_ll i_rel) const { return t_s + (smprate ? i_rel / smprate : 0); }
  double dt_s(s_ll i_rel) const { return (smprate ? i_rel / smprate : 0); }
};


}


#endif
