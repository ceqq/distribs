================================================================

This project presents a generic host application,
which is able to load and execute multiple plugins,
created with different compilers on the same platform.

The host application does not distinguish the kind of plugins it's loading.

================================================================

Binary files.

In the scope of example project, 3 kinds of plugins are defined,
working according to the following scheme:

Data source --> data processor --> data endpoint (final consumer).

The data is 1 channel of audio samples, which are averaged,
and volume level is calculated and displayed.

Roles of the binary modules, compiled from project files:

plhost (executable):
  load configuration, load plugins, start threads, watch termination conditions,
  ensure threads completion, exit.

supplier1 (shared library):
  load wav, push audio samples into the input data queue.

processor1 (shared library):
  pop samples, calc. avg. amplitude for a time window,
  push amplitude into the output data queue.

indicator1 (shared library):
  pop volume (avg. amplitude) values,
  display time and volume in terminal window.

================================================================

Build.

NOTE 1

Before building binaries of this project,
please ensure you downloaded BMDX library:

hashx.dp.ua/cpp_bmdx_1.1_r1.zip

Note: rev. number (r1) may be different!

Unpack the archive into ./src_code folder.
Final paths should look like:

./src_code/cpp_bmdx_1.1/src_code/bmdx_main.h

NOTE 2

For each particular platform, there is a build script (bldwin.cmd, bldlin etc.),
compiling 4 binaries (host executable and 3 plugins),
by default, using one compiler.

Most of the scripts support 2 compilers, allowing to choose
different compiler for each output binary. For example,
  bldwin 1 2 2 2
builds host executable with MinGW, and all plugins with MSVC.

Default settings:
Windows:
  MinGW: c:\mingw\bin\g++.exe
  MSVC: C:\Program Files (x86)\Microsoft Visual Studio 12.0
POSIX:
  Scripts may require tuning (set the correct path to compilers).

================================================================

Architectural note.

The number and parameters of plugins are specified in plhost.cfg.
Each plugin binary, once loaded, may be used to create multiple plugin instances.
The host assumes that each plugin instance is a thread + additional objects.

The example connects data supplier to consumers (1:many) to pass them data.
A consumer plugin instance asks for data queue creation
from the supplier plugin instance, to which the consumer is bound by configuration.
Values in the queue are held in blocks, by reference (ref.-counted).
Blocks are shared between consumers, to efficiently address large amount of data.

(This particular data queues architecture concerns only with plugins in the example.
Any other plugins are not required to use or depend on it.)

The host asks all live threads to exit in any of the following cases:
a) All plugin instances (threads), configured as data endpoint, had exited.
b) All plugin instances have exited.
c) Any of the plugin instances exited due to error (had not set normal exit code).
d) The user presses Esc.
  (Reading keyboard input by the host is implemented as example only.
  In real application, the input would be handled by separate kind of plugin.)

================================================================
